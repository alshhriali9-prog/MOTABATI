import React, { useEffect, useMemo, useState } from "react";
import { Search, Plus, LayoutDashboard, Users, ClipboardCheck, BookOpen, HelpCircle, CalendarDays, FileText, Award, Bell, ChevronLeft, X, Check, Clock, Sparkles, Eye, EyeOff, Trash2, GraduationCap, Heart, Menu, Pencil, ListChecks, MessageCircle, Save, Phone, Copy, ShieldAlert, Trophy, Star, Medal, Crown, Shuffle, AlertTriangle, TrendingUp, Target, Gift, CalendarCheck, RotateCcw, Send, RefreshCw, Upload, Download, Archive, ArchiveRestore, ExternalLink, FileSpreadsheet, ShieldCheck, Info } from "lucide-react";
import studentsData from "./assets/8cea73d6802c31ad-students_clean.json";
import teacherPhotoUrl from "container:///mnt/data/src/assets/1cf37c911de3fec9-Screenshot_________________WhatsApp_-_____.jpg";
import schoolImageUrl from "container:///mnt/data/src/assets/c6d34972cb1f1c45-image_20261113_145441.webp";
// أرقام التواصل مصدرها الوحيد ملفات الإكسل الأربعة للفصول (عمود «جوال ولي الأمر»).
// لا تُضمَّن أي أرقام في الكود ولا يُضاف أي رقم من خارج تلك الملفات.
// ملفات الإكسل لا تُبنى كوسائط داخل الصفحة الواحدة، لذلك لا يُعرض هنا أي رقم
// غير مطابق لاسم الابن / ولي الأمر في تلك الملفات.

// ---------- Records API ----------
async function api(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json().catch(() => ({}));
  if (!res.ok || j?.error) throw new Error(j?.error || `تعذّر الاتصال (${res.status})`);
  return j.data;
}
type Ev = { id: string; title: string; desc: string; kind: string; date: string; pending?: boolean };
type RawStudent = { name: string; class: string; guardian: string; school: string; status: string };

const RAW = studentsData as unknown as RawStudent[];
const CLASS_ORDER = ["اول/4", "ثالث/1", "ثالث/2", "ثالث/3"];
const CLASS_META: Record<string, { grade: string; color: string; note: string }> = {
  "اول/4": { grade: "الصف الأول", color: "#6D28D9", note: "بداياتهم الجميلة — نرعاهم بحب ونبني أساسهم خطوة بخطوة" },
  "ثالث/1": { grade: "الصف الثالث", color: "#10B981", note: "ثقة تكبر كل يوم — يقرؤون ويعبّرون ويشاركون بحماس" },
  "ثالث/2": { grade: "الصف الثالث", color: "#0EA5E9", note: "فضول وطاقة — نوجّهها نحو التعلّم والتعاون" },
  "ثالث/3": { grade: "الصف الثالث", color: "#F59E0B", note: "أبناءٌ مجتهدون — نثمّن تقدمهم ونحتفي بإنجازهم" },
};
function hashStr(s: string) { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 997; return h; }
type Student = RawStudent & { id: string; className: string };
const ALL_STUDENTS: Student[] = RAW.map((s, i) => ({ ...s, id: `s-${i}`, className: s.class }));
const CLASSES = CLASS_ORDER.map((name) => ({
  id: name, name, grade: CLASS_META[name].grade, color: CLASS_META[name].color, note: CLASS_META[name].note,
  students: ALL_STUDENTS.filter((s) => s.className === name).length,
}));
const QUESTIONS = [
  { id: "q1", text: "ما ناتج 7 + 8 ؟", subject: "رياضيات", grade: "الصف الأول", type: "اختيار من متعدد", level: "سهل" },
  { id: "q2", text: "هل الماء يتكوّن من الهيدروجين والأكسجين؟", subject: "علوم", grade: "الصف الثالث", type: "صح وخطأ", level: "سهل" },
  { id: "q3", text: "اكتب جملة مفيدة فيها فعل مضارع، ثم حدّد الفعل.", subject: "لغة عربية", grade: "الصف الثالث", type: "مقالي", level: "متوسط" },
  { id: "q4", text: "أي الأشكال الآتية له أربعة أضلاع متساوية؟", subject: "رياضيات", grade: "الصف الثالث", type: "اختيار من متعدد", level: "متوسط" },
  { id: "q5", text: "لماذا نرى القمر مضيئاً في الليل؟ فسّر إجابتك.", subject: "علوم", grade: "الصف الثالث", type: "مقالي", level: "متقدم" },
  { id: "q6", text: "ضع علامة الترقيم المناسبة في نهاية الجملة الاستفهامية.", subject: "لغة عربية", grade: "الصف الأول", type: "صح وخطأ", level: "سهل" },
];
const WEEK_DAYS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"];
const DEFAULT_WEEK: Record<string, { time: string; title: string; cls: string }[]> = {
  "الأحد": [{ time: "08:00", title: "الجمع حتى 20", cls: "اول/4" }, { time: "10:00", title: "أجزاء النبات", cls: "ثالث/1" }],
  "الاثنين": [{ time: "08:00", title: "القراءة الجهرية", cls: "ثالث/2" }],
  "الثلاثاء": [{ time: "09:00", title: "الطرح بالاستلاف", cls: "ثالث/3" }],
  "الأربعاء": [{ time: "08:00", title: "الكسور البسيطة", cls: "اول/4" }],
  "الخميس": [{ time: "10:00", title: "مراجعة عامة", cls: "ثالث/1" }],
};

// ---------- Guardian phones from Excel ----------
function normalizePhone(raw: string | number | null | undefined): string | null {
  if (raw === null || raw === undefined) return null;
  let s = String(raw).trim().replace(/[\s\-()]/g, "");
  if (s.startsWith("+")) s = s.slice(1);
  if (s.startsWith("00966")) s = "966" + s.slice(5);
  s = s.replace(/\D/g, "");
  if (!s) return null;
  if (s.length === 12 && s.startsWith("966")) return s;
  if (s.length === 10 && s.startsWith("05")) return "966" + s.slice(1);
  if (s.length === 9 && s.startsWith("5")) return "966" + s;
  if (s.length === 10 && s.startsWith("5")) return "966" + s.slice(1);
  return null;
}
function toLocalPhone(normalized: string): string {
  if (normalized.startsWith("966") && normalized.length === 12) return "0" + normalized.slice(3);
  return normalized;
}
function maskPhone(normalized: string): string {
  const local = toLocalPhone(normalized);
  if (local.length >= 5) return `${local.slice(0, 2)}***...${local.slice(-3)}`;
  return "***";
}
function normName(s: string): string {
  return (s || "").trim().replace(/\s+/g, " ").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[ًٌٍَُِّْـ]/g, "");
}
function colLettersToIndex(letters: string): number {
  let n = 0;
  for (let i = 0; i < letters.length; i++) n = n * 26 + (letters.charCodeAt(i) - 64);
  return n - 1;
}
async function unzipFiles(buf: ArrayBuffer): Promise<Map<string, Uint8Array>> {
  const view = new DataView(buf);
  let eocd = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) {
    if (view.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error("zip");
  const total = view.getUint16(eocd + 10, true);
  const cdOffset = view.getUint32(eocd + 16, true);
  const map = new Map<string, Uint8Array>();
  let p = cdOffset;
  for (let k = 0; k < total; k++) {
    if (view.getUint32(p, true) !== 0x02014b50) break;
    const method = view.getUint16(p + 10, true);
    const compSize = view.getUint32(p + 20, true);
    const nameLen = view.getUint16(p + 28, true);
    const extraLen = view.getUint16(p + 30, true);
    const commentLen = view.getUint16(p + 32, true);
    const localOffset = view.getUint32(p + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(buf, p + 46, nameLen));
    const lhNameLen = view.getUint16(localOffset + 26, true);
    const lhExtraLen = view.getUint16(localOffset + 28, true);
    const dataStart = localOffset + 30 + lhNameLen + lhExtraLen;
    const comp = new Uint8Array(buf, dataStart, compSize);
    let out: Uint8Array;
    if (method === 0) out = comp;
    else if (method === 8) {
      const DS = (window as any).DecompressionStream;
      const ds = new DS("deflate-raw");
      const decompressed = await new Response(new Blob([comp as unknown as BlobPart]).stream().pipeThrough(ds)).arrayBuffer();
      out = new Uint8Array(decompressed);
    } else { p += 46 + nameLen + extraLen + commentLen; continue; }
    map.set(name, out);
    p += 46 + nameLen + extraLen + commentLen;
  }
  return map;
}
function parseSharedStrings(text: string): string[] {
  try {
    const doc = new DOMParser().parseFromString(text, "text/xml");
    const sis = Array.from(doc.getElementsByTagName("si"));
    return sis.map((si) => Array.from(si.getElementsByTagName("t")).map((t) => t.textContent || "").join(""));
  } catch { return []; }
}
function parseSheetXml(text: string, shared: string[]): string[][] {
  try {
    const doc = new DOMParser().parseFromString(text, "text/xml");
    const rows = Array.from(doc.getElementsByTagName("row"));
    return rows.map((row) => {
      const arr: string[] = [];
      const cells = Array.from(row.getElementsByTagName("c"));
      cells.forEach((c) => {
        const r = c.getAttribute("r") || "";
        const m = r.match(/^([A-Z]+)/);
        if (!m) return;
        const idx = colLettersToIndex(m[1]);
        const t = c.getAttribute("t") || "";
        let val = "";
        if (t === "s") {
          const v = c.getElementsByTagName("v")[0];
          const n = v ? parseInt(v.textContent || "-1", 10) : -1;
          val = n >= 0 && n < shared.length ? shared[n] : "";
        } else if (t === "inlineStr") {
          const isEl = c.getElementsByTagName("is")[0];
          val = isEl ? Array.from(isEl.getElementsByTagName("t")).map((x) => x.textContent || "").join("") : "";
        } else {
          const v = c.getElementsByTagName("v")[0];
          val = v ? (v.textContent || "") : "";
          const isEl = c.getElementsByTagName("is")[0];
          if (!val && isEl) val = Array.from(isEl.getElementsByTagName("t")).map((x) => x.textContent || "").join("");
        }
        arr[idx] = val;
      });
      return arr;
    });
  } catch { return []; }
}
type ExcelEntry = { name: string; guardian: string; phone: string };
async function parseWorkbook(buf: ArrayBuffer): Promise<ExcelEntry[]> {
  try {
    const files = await unzipFiles(buf);
    let shared: string[] = [];
    const sharedBytes = files.get("xl/sharedStrings.xml");
    if (sharedBytes) shared = parseSharedStrings(new TextDecoder().decode(sharedBytes));
    const sheetNames = Array.from(files.keys()).filter((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort();
    const out: ExcelEntry[] = [];
    for (const sheetName of sheetNames) {
      const bytes = files.get(sheetName);
      if (!bytes) continue;
      const rows = parseSheetXml(new TextDecoder().decode(bytes), shared);
      const headerIdx = rows.findIndex((row) => row.some((cell) => cell && cell.includes("جوال")));
      if (headerIdx === -1) continue;
      const header = rows[headerIdx];
      const phoneCol = header.findIndex((cell) => cell && cell.includes("جوال"));
      let nameCol = header.findIndex((cell) => cell && (cell.includes("الطالب") || cell.includes("اسم")));
      if (nameCol === -1) nameCol = 0;
      const guardianCol = header.findIndex((cell) => cell && cell.includes("ولي"));
      for (let i = headerIdx + 1; i < rows.length; i++) {
        const row = rows[i] || [];
        const rawPhone = row[phoneCol] || "";
        const phone = normalizePhone(rawPhone);
        if (!phone) continue;
        const name = (row[nameCol] || "").trim();
        const guardian = guardianCol >= 0 ? (row[guardianCol] || "").trim() : "";
        if (!name && !guardian) continue;
        out.push({ name: name || guardian, guardian, phone });
      }
    }
    return out;
  } catch { return []; }
}
async function loadPhonesFromExcel(): Promise<Record<string, string>> {
  const entries: ExcelEntry[] = [];
  const byName = new Map<string, string>();
  const byGuardian = new Map<string, string>();
  entries.forEach((e) => {
    const n = normName(e.name);
    if (n && !byName.has(n)) byName.set(n, e.phone);
    const g = normName(e.guardian);
    if (g && !byGuardian.has(g)) byGuardian.set(g, e.phone);
  });
  const map: Record<string, string> = {};
  ALL_STUDENTS.forEach((s) => {
    const nn = normName(s.name);
    const gg = normName(s.guardian);
    let ph = byName.get(nn) || byGuardian.get(gg);
    if (!ph) {
      const tokens = nn.split(" ").filter(Boolean);
      if (tokens.length >= 2) {
        const key2 = tokens.slice(0, 2).join(" ");
        const found = entries.find((e) => {
          const en = normName(e.name).split(" ").filter(Boolean);
          return en.length >= 2 && en.slice(0, 2).join(" ") === key2;
        });
        if (found) ph = found.phone;
      }
    }
    if (!ph) {
      const gTokens = gg.split(" ").filter(Boolean);
      if (gTokens.length >= 2) {
        const key2 = gTokens.slice(0, 2).join(" ");
        const found = entries.find((e) => {
          const eg = normName(e.guardian).split(" ").filter(Boolean);
          return eg.length >= 2 && eg.slice(0, 2).join(" ") === key2;
        });
        if (found) ph = found.phone;
      }
    }
    if (ph) map[s.id] = ph;
  });
  return map;
}
const WHATSAPP_TEXT = "السلام عليكم، معك أ. عبدالعزيز معلم ابنك في مدرسة الربيع بن زياد الابتدائية";
const MADRASATI_URL = "https://schools.madrasati.sa";
type RosterRow = { name: string; className: string; guardian?: string; studentNo?: string };
type RosterPreview = { added: RosterRow[]; moved: { student: Student; from: string; to: string }[]; missing: Student[]; unchanged: number };
function normalizeClassName(raw: string): string | null {
  const s = (raw || "").trim().replace(/[ـ]/g, "").replace(/\s+/g, " ");
  if (!s) return null;
  const hasOne = /اول|أول|الاول|الأول|الصف الاول|grade\s*1|\b1\b/.test(s);
  const hasThree = /ثالث|الصف الثالث|grade\s*3|\b3\b/.test(s);
  const m = s.match(/([1-4])\s*$/ ) || s.match(/\/\s*([1-4])/) || s.match(/([1-4])\s*$/);
  const sec = m ? m[1] : (s.includes("4") ? "4" : s.includes("1") ? "1" : s.includes("2") ? "2" : s.includes("3") ? "3" : "");
  if (hasOne && sec === "4") return "اول/4";
  if (hasThree && ["1", "2", "3"].includes(sec)) return `ثالث/${sec}`;
  if (CLASS_ORDER.includes(s.replace(" ", ""))) return s.replace(" ", "");
  if (s === "اول/4" || s === "ثالث/1" || s === "ثالث/2" || s === "ثالث/3") return s;
  return null;
}
function parseCsvText(text: string): RosterRow[] {
  const lines = text.replace(/\r/g, "").split("\n").map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return [];
  const split = (line: string) => line.split(/[,;،\t]/).map((c) => c.trim().replace(/^"|"$/g, ""));
  const header = split(lines[0]);
  const nameCol = header.findIndex((c) => c.includes("الطالب") || c.includes("اسم"));
  const classCol = header.findIndex((c) => c.includes("الفصل") || c.includes("الشعبة") || c.includes("الصف"));
  const guardianCol = header.findIndex((c) => c.includes("ولي"));
  const idCol = header.findIndex((c) => c.includes("رقم الطالب") || c.includes("رقم") || c.includes("الهوية"));
  if (nameCol === -1 || classCol === -1) return [];
  const out: RosterRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cells = split(lines[i]);
    const name = (cells[nameCol] || "").trim();
    const cls = normalizeClassName(cells[classCol] || "");
    if (!name || !cls) continue;
    out.push({ name, className: cls, guardian: guardianCol >= 0 ? (cells[guardianCol] || "").trim() : undefined, studentNo: idCol >= 0 ? (cells[idCol] || "").trim() : undefined });
  }
  return out;
}
async function parseRosterXlsx(buf: ArrayBuffer): Promise<RosterRow[]> {
  const files = await unzipFiles(buf);
  let shared: string[] = [];
  const sb = files.get("xl/sharedStrings.xml");
  if (sb) shared = parseSharedStrings(new TextDecoder().decode(sb));
  const sheetNames = Array.from(files.keys()).filter((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort();
  const out: RosterRow[] = [];
  for (const sn of sheetNames) {
    const bytes = files.get(sn); if (!bytes) continue;
    const rows = parseSheetXml(new TextDecoder().decode(bytes), shared);
    const headerIdx = rows.findIndex((r) => r.some((c) => c && (c.includes("الطالب") || c.includes("اسم"))) && r.some((c) => c && (c.includes("الفصل") || c.includes("الشعبة") || c.includes("الصف"))));
    if (headerIdx === -1) continue;
    const header = rows[headerIdx];
    const nameCol = header.findIndex((c) => c && (c.includes("الطالب") || c.includes("اسم")));
    const classCol = header.findIndex((c) => c && (c.includes("الفصل") || c.includes("الشعبة") || c.includes("الصف")));
    const guardianCol = header.findIndex((c) => c && c.includes("ولي"));
    const idCol = header.findIndex((c) => c && (c.includes("رقم الطالب") || c.includes("الهوية")));
    for (let i = headerIdx + 1; i < rows.length; i++) {
      const row = rows[i] || [];
      const name = (row[nameCol] || "").trim();
      const cls = normalizeClassName(row[classCol] || "");
      if (!name || !cls) continue;
      out.push({ name, className: cls, guardian: guardianCol >= 0 ? (row[guardianCol] || "").trim() : undefined, studentNo: idCol >= 0 ? (row[idCol] || "").trim() : undefined });
    }
  }
  return out;
}
function buildRosterPreview(current: Student[], incoming: RosterRow[]): RosterPreview {
  const byName = new Map(current.map((s) => [normName(s.name), s]));
  const incomingNames = new Set(incoming.map((r) => normName(r.name)));
  const added: RosterRow[] = []; const moved: RosterPreview["moved"] = []; let unchanged = 0;
  incoming.forEach((r) => {
    const ex = byName.get(normName(r.name));
    if (!ex) added.push(r);
    else if (ex.className !== r.className) moved.push({ student: ex, from: ex.className, to: r.className });
    else unchanged++;
  });
  const missing = current.filter((s) => !incomingNames.has(normName(s.name)));
  const dedupAdded = added.filter((r, i) => added.findIndex((x) => normName(x.name) === normName(r.name)) === i);
  return { added: dedupAdded, moved, missing, unchanged };
}

// ---------- New features data ----------
const MEDALS = [
  { id: "reading", label: "نجم القراءة", emoji: "📖", color: "#6D28D9", bg: "#F0E9FF" },
  { id: "attendance", label: "نجم الحضور", emoji: "📍", color: "#10B981", bg: "#E7F9F1" },
  { id: "ethics", label: "نجم الأخلاق", emoji: "💛", color: "#F59E0B", bg: "#FEF3C7" },
  { id: "homework", label: "نجم الواجبات", emoji: "✏️", color: "#0EA5E9", bg: "#E0F2FE" },
  { id: "improvement", label: "نجم التحسّن", emoji: "🚀", color: "#F43F5E", bg: "#FFE4E6" },
];
const SKILLS = ["قراءة", "إملاء", "رياضيات", "حفظ"];
const PLAN_TEMPLATES: Record<string, { goal: string; activities: string[]; worksheet: string; homeHelp: string }> = {
  "قراءة": { goal: "أن يقرأ ابني جملاً قصيرة بطلاقة وثقة خلال أسبوعين.", activities: ["قراءة يومية 10 دقائق من قصة قصيرة بصوت مرتفع.", "لعبة البطاقات: قراءة كلمة ثم تركيبها في جملة.", "قراءة ثنائية مع زميل متفوق ثم قراءة منفردة أمام الفصل."], worksheet: "ورقة عمل: اقرأ ثم لون الكلمة الصحيحة — 10 كلمات متدرجة.", homeHelp: "خصصوا 10 دقائق يومياً للقراءة معه، وامدحوا كل محاولة قبل التصحيح." },
  "إملاء": { goal: "أن يكتب ابني كلمات شائعة إملاءً صحيحاً بنسبة 80% خلال أسبوعين.", activities: ["إملاء منظور: يقرأ الكلمة، يغطيها، ثم يكتبها.", "لعبة الحروف الناقصة: أكمل الحرف الناقص في 8 كلمات.", "كتابة 3 جمل يومياً بخط جميل مع مراجعة ذاتية."], worksheet: "ورقة عمل: إملاء 10 كلمات + تصحيح ذاتي باللون الأخضر.", homeHelp: "أمليه 5 كلمات يومياً بهدوء، واطلب منه أن يقرأ ما كتب بصوت مرتفع." },
  "رياضيات": { goal: "أن يتقن ابني الجمع والطرح حتى 20 دون عدّ بالأصابع خلال أسبوعين.", activities: ["مكعبات العدّ: مثّل المسألة بمكعبات ثم اكتبها.", "لعبة بطاقات الجمع السريع — 10 بطاقات في دقيقتين.", "مسائل حياتية: كم بقي معك إذا اشتريت…؟"], worksheet: "ورقة عمل: 12 مسألة جمع وطرح متدرجة + مسألة حياتية واحدة.", homeHelp: "اسألوه في الحياة اليومية: كم عدد الأطباق؟ كم بقي؟ واجعلوا الحساب لعبة." },
  "حفظ": { goal: "أن يحفظ ابني النص المقرر بثقة ويسترجعه دون تردد خلال أسبوعين.", activities: ["حفظ مجزأ: سطر واحد يومياً مع التكرار بصوت مرتفع.", "لعبة الإكمال: أبدأ الجملة وهو يكملها.", "تسجيل صوتي لنفسه والاستماع إليه قبل النوم."], worksheet: "ورقة عمل: أكمل الفراغات في النص المحفوظ + رتّب الجمل.", homeHelp: "راجعوا معه قبل النوم 5 دقائق فقط، وشجعوه أن يسمّع لكم بابتسامة." },
};
const ENRICHMENT_TEMPLATE = { goal: "أن يواصل ابني تفوقه ويقود زملاءه بثقة وإبداع.", activities: ["تحدي القراءة: 3 قصص في أسبوعين مع تلخيص شفهي لكل قصة.", "نشاط إثرائي: مشروع صغير — مجلة الفصل أو لوحة اكتشافات.", "مهمة قيادية: مساعد المعلم — يشرح لزميله خطوة واحدة ويشجعه."], worksheet: "ورقة عمل إثرائية: سؤال مفتوح للتفكير + تحدي إبداعي من اختياره.", homeHelp: "امنحوه كتاباً من اختياره، واسألوه: ماذا تعلمت اليوم؟ واحتفلوا بإنجازه." };
type PlanValue = { skill: string; kind: string; goal: string; activities: string[]; worksheet: string; homeHelp: string; status: string; progress: number };
type HonorAward = { id: string; studentId: string; studentName: string; className: string; medal: string; date: string };
type SonRecord = { id: string; studentId: string; studentName: string; className: string; date: string; reason: string };

export default function App() {
  const [section, setSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedClass, setSelectedClass] = useState("اول/4");
  const [classTab, setClassTab] = useState("students");
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [attendance, setAttendance] = useState<Record<string, string>>({});
  const [grades, setGrades] = useState<Record<string, { h: number; p: number; b: number }>>(() => Object.fromEntries(ALL_STUDENTS.map((s) => {
    const h = hashStr(s.name);
    return [s.id, { h: 7 + (h % 4), p: 7 + (Math.floor(h / 4) % 4), b: 8 + (Math.floor(h / 16) % 3) }];
  })));
  const [editingGrade, setEditingGrade] = useState<string | null>(null);
  const [gradeDraft, setGradeDraft] = useState("");
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [noteRecordIds, setNoteRecordIds] = useState<Record<string, string>>({});
  const [excelPhones, setExcelPhones] = useState<Record<string, string>>({});
  const [phonesLoading, setPhonesLoading] = useState(true);
  const [phonesError, setPhonesError] = useState("");
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [contactSearch, setContactSearch] = useState("");
  const [evidence, setEvidence] = useState<Ev[]>([
    { id: "e1", title: "تحضير درس الجمع حتى 20", desc: "تحضير مكتمل بأهداف وأنشطة وتقويم ختامي لفصل اول/4.", kind: "تحضير الدروس", date: "هذا الأسبوع" },
    { id: "e2", title: "خطة علاجية للقراءة", desc: "خطة دعم فردية لعدد من الأبناء في فصل ثالث/1 مع أنشطة متدرجة.", kind: "خطط علاجية", date: "هذا الأسبوع" },
    { id: "e3", title: "سجل متابعة فصل ثالث/2", desc: "توثيق الواجب والمشاركة والسلوك للأسبوع الثالث.", kind: "سجلات متابعة", date: "الأسبوع الماضي" },
    { id: "e4", title: "نشاط إثرائي: حديقة العلوم", desc: "نشاط عملي لتصنيف النباتات وربطها بحياة الأبناء.", kind: "أنشطة إثرائية", date: "الأسبوع الماضي" },
  ]);
  const [showEvidenceForm, setShowEvidenceForm] = useState(false);
  const [evTitle, setEvTitle] = useState(""); const [evDesc, setEvDesc] = useState(""); const [evKind, setEvKind] = useState("تحضير الدروس");
  const [qSubject, setQSubject] = useState("الكل"); const [qGrade, setQGrade] = useState("الكل");
  const [testQs, setTestQs] = useState<typeof QUESTIONS>([QUESTIONS[0]]);
  const [week, setWeek] = useState(DEFAULT_WEEK);
  const [editingLesson, setEditingLesson] = useState<{ day: string; idx: number } | null>(null);
  const [lessonDraft, setLessonDraft] = useState("");
  const [report, setReport] = useState<string | null>(null);
  const [reportClass, setReportClass] = useState("اول/4");
  const [showTestPreview, setShowTestPreview] = useState(false);
  const [showNewSession, setShowNewSession] = useState(false);
  const [showNewPrep, setShowNewPrep] = useState(false);
  const [newPrepTitle, setNewPrepTitle] = useState(""); const [newPrepDay, setNewPrepDay] = useState("الأحد");
  const [toast, setToast] = useState(""); const [busy, setBusy] = useState(false);
  const [saveInfo, setSaveInfo] = useState("");
  const [backendNote, setBackendNote] = useState("");
  const [showMessage, setShowMessage] = useState(false);
  const [showTeacherCard, setShowTeacherCard] = useState(false);
  const [showPresentation, setShowPresentation] = useState(false);
  const [slide, setSlide] = useState(0);
  const [messageKind, setMessageKind] = useState("تقدير");

  // ---------- New sections state ----------
  const [weeklyClass, setWeeklyClass] = useState("اول/4");
  const [weeklyStudentId, setWeeklyStudentId] = useState(ALL_STUDENTS.find(s=>s.className==="اول/4")?.id || ALL_STUDENTS[0].id);
  const [weeklySearch, setWeeklySearch] = useState("");
  const [batchSearch, setBatchSearch] = useState("");
  const [showBatch, setShowBatch] = useState(false);
  const [weeklyPresent, setWeeklyPresent] = useState<Record<string, number>>({});
  const [weeklyAbsent, setWeeklyAbsent] = useState<Record<string, number>>({});
  const [plans, setPlans] = useState<Record<string, PlanValue>>({});
  const [planRecordIds, setPlanRecordIds] = useState<Record<string, string>>({});
  const [planSkill, setPlanSkill] = useState("قراءة");
  const [planKind, setPlanKind] = useState("علاجية");
  const [planGoal, setPlanGoal] = useState("");
  const [planActivities, setPlanActivities] = useState("");
  const [planWorksheet, setPlanWorksheet] = useState("");
  const [planHome, setPlanHome] = useState("");
  const [planStatus, setPlanStatus] = useState("قيد التنفيذ");
  const [planProgress, setPlanProgress] = useState(30);
  const [growthNotes, setGrowthNotes] = useState<Record<string, string>>({});
  const [growthIds, setGrowthIds] = useState<Record<string, string>>({});
  const [awards, setAwards] = useState<HonorAward[]>([]);
  const [honorClass, setHonorClass] = useState("الكل");
  const [honorMedal, setHonorMedal] = useState("الكل");
  const [honorStudentId, setHonorStudentId] = useState(ALL_STUDENTS[0].id);
  const [honorMedalPick, setHonorMedalPick] = useState("reading");
  const [sonClass, setSonClass] = useState("اول/4");
  const [sonCandidateId, setSonCandidateId] = useState<string>("");
  const [sonHistory, setSonHistory] = useState<SonRecord[]>([]);
  const [evaluations, setEvaluations] = useState<Record<string, { att: string; hw: string; part: string; beh: string }>>({});
  const [alertSearch, setAlertSearch] = useState("");
  const [drawClass, setDrawClass] = useState("اول/4");
  const [drawPool, setDrawPool] = useState<string[]>([]);
  const [drawHistory, setDrawHistory] = useState<Student[]>([]);
  const [currentDraw, setCurrentDraw] = useState<Student | null>(null);
  const [drawSpinning, setDrawSpinning] = useState(false);
  const [showWeeklyMsg, setShowWeeklyMsg] = useState(false);
  const [showAbsenceMsgFor, setShowAbsenceMsgFor] = useState<string | null>(null);
  // ---------- تحديث قائمة الطلاب من مدرستي ----------
  const [roster, setRoster] = useState<Student[]>(ALL_STUDENTS);
  const [archived, setArchived] = useState<Student[]>([]);
  const [rosterRecordIds, setRosterRecordIds] = useState<Record<string, string>>({});
  const [archivedRecordIds, setArchivedRecordIds] = useState<Record<string, string>>({});
  const [lastSyncAt, setLastSyncAt] = useState<string>("لم يتم التحديث بعد");
  const [syncFileName, setSyncFileName] = useState("");
  const [syncPreview, setSyncPreview] = useState<RosterPreview | null>(null);
  const [syncIncoming, setSyncIncoming] = useState<RosterRow[]>([]);
  const [syncError, setSyncError] = useState("");
  const [syncParsing, setSyncParsing] = useState(false);
  const [syncConfirming, setSyncConfirming] = useState(false);
  const [syncResult, setSyncResult] = useState<{ saved: number; remaining: number; error: string | null; reloadError: string | null } | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [selectedAdded, setSelectedAdded] = useState<Record<string, boolean>>({});
  const [selectedMoved, setSelectedMoved] = useState<Record<string, boolean>>({});
  const [selectedMissing, setSelectedMissing] = useState<Record<string, boolean>>({});
  const [archivedSearch, setArchivedSearch] = useState("");
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [ev, nt, pl, hn, son, gr]: any[] = await Promise.all([
          api("records.list", { collection: "evidence" }),
          api("records.list", { collection: "student_notes" }),
          api("records.list", { collection: "student_plans" }),
          api("records.list", { collection: "honor_awards" }),
          api("records.list", { collection: "son_of_week" }),
          api("records.list", { collection: "growth_notes" }),
        ]);
        const rows = (ev?.records || []).map((r: any) => ({ id: r.id, ...r.value }));
        if (rows.length) setEvidence((prev) => [...rows, ...prev.filter((p) => !rows.some((x: any) => x.title === p.title))]);
        const nMap: Record<string, string> = {}; const idMap: Record<string, string> = {};
        (nt?.records || []).forEach((r: any) => { if (r?.value?.studentId && r?.value?.note) { nMap[r.value.studentId] = r.value.note; idMap[r.value.studentId] = r.id; } });
        if (Object.keys(nMap).length) { setNotes(nMap); setNoteRecordIds(idMap); }
        const pMap: Record<string, PlanValue> = {}; const pIds: Record<string, string> = {};
        (pl?.records || []).forEach((r: any) => { if (r?.value?.studentId) { pMap[r.value.studentId] = r.value as PlanValue; pIds[r.value.studentId] = r.id; } });
        if (Object.keys(pMap).length) { setPlans(pMap); setPlanRecordIds(pIds); }
        const aRows: HonorAward[] = (hn?.records || []).map((r: any) => ({ id: r.id, ...r.value }));
        if (aRows.length) setAwards(aRows);
        const sRows: SonRecord[] = (son?.records || []).map((r: any) => ({ id: r.id, ...r.value }));
        if (sRows.length) setSonHistory(sRows);
        const gMap: Record<string, string> = {}; const gIds: Record<string, string> = {};
        (gr?.records || []).forEach((r: any) => { if (r?.value?.studentId) { gMap[r.value.studentId] = r.value.text || ""; gIds[r.value.studentId] = r.id; } });
        if (Object.keys(gMap).length) { setGrowthNotes(gMap); setGrowthIds(gIds); }
      } catch { setBackendNote("الحفظ الدائم غير متاح الآن في هذه المعاينة — تعمل التعديلات داخل الجلسة."); }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const m = await loadPhonesFromExcel();
        setExcelPhones(m);
        if (Object.keys(m).length === 0) setPhonesError("لم يتم العثور على أرقام في ملفات الفصول — تحقق من ملفات الإكسل.");
      } catch { setPhonesError("تعذّر قراءة ملفات أرقام التواصل."); }
      setPhonesLoading(false);
    })();
  }, []);

  // Sync plan form when student modal opens
  useEffect(() => {
    if (!selectedStudent) return;
    const existing = plans[selectedStudent.id];
    const total = (grades[selectedStudent.id]?.h || 0) + (grades[selectedStudent.id]?.p || 0) + (grades[selectedStudent.id]?.b || 0);
    if (existing) {
      setPlanSkill(existing.skill); setPlanKind(existing.kind); setPlanGoal(existing.goal); setPlanActivities(existing.activities.join("\n")); setPlanWorksheet(existing.worksheet); setPlanHome(existing.homeHelp); setPlanStatus(existing.status); setPlanProgress(existing.progress);
    } else {
      const isTop = total >= 25;
      const kind = isTop ? "إثرائية" : "علاجية";
      setPlanKind(kind);
      if (kind === "إثرائية") { setPlanSkill("قراءة"); setPlanGoal(ENRICHMENT_TEMPLATE.goal); setPlanActivities(ENRICHMENT_TEMPLATE.activities.join("\n")); setPlanWorksheet(ENRICHMENT_TEMPLATE.worksheet); setPlanHome(ENRICHMENT_TEMPLATE.homeHelp); }
      else { const t = PLAN_TEMPLATES["قراءة"]; setPlanSkill("قراءة"); setPlanGoal(t.goal); setPlanActivities(t.activities.join("\n")); setPlanWorksheet(t.worksheet); setPlanHome(t.homeHelp); }
      setPlanStatus("قيد التنفيذ"); setPlanProgress(30);
    }
  }, [selectedStudent?.id]);

  const flash = (t: string) => { setToast(t); setTimeout(() => setToast(""), 3200); };
  const liveClasses = CLASS_ORDER.map((name) => ({ id: name, name, grade: CLASS_META[name].grade, color: CLASS_META[name].color, note: CLASS_META[name].note, students: roster.filter((s) => s.className === name).length }));
  const cls = liveClasses.find((c) => c.id === selectedClass)!;
  const classStudents = roster.filter((s) => s.className === selectedClass);
  const reportStudents = roster.filter((s) => s.className === reportClass);
  const filteredStudents = roster.filter((s) => s.name.includes(search) || s.guardian.includes(search) || s.className.includes(search));
  const attCounts = useMemo(() => {
    let p = 0, a = 0, l = 0;
    classStudents.forEach((s) => { const v = attendance[s.id]; if (v === "غائب") a++; else if (v === "متأخر") l++; else p++; });
    return { p, a, l };
  }, [attendance, selectedClass]);
  const totalAbsent = roster.filter((s) => attendance[s.id] === "غائب").length;
  const totalLate = roster.filter((s) => attendance[s.id] === "متأخر").length;
  const todayPct = Math.round(((roster.length - totalAbsent) / Math.max(1, roster.length)) * 100);
  const filteredQs = QUESTIONS.filter((q) => (qSubject === "الكل" || q.subject === qSubject) && (qGrade === "الكل" || q.grade === qGrade));
  const topStudents = useMemo(() => [...reportStudents].sort((a, b) => (grades[b.id].h + grades[b.id].p + grades[b.id].b) - (grades[a.id].h + grades[a.id].p + grades[a.id].b)).slice(0, 5), [reportClass, grades]);
  const contactFilteredAll = useMemo(() => {
    const q = contactSearch.trim();
    if (!q) return roster;
    return roster.filter((s) => s.name.includes(q) || s.guardian.includes(q));
  }, [contactSearch, roster]);
  const contactFilteredClass = useMemo(() => {
    const q = contactSearch.trim();
    if (!q) return classStudents;
    return classStudents.filter((s) => s.name.includes(q) || s.guardian.includes(q));
  }, [contactSearch, selectedClass]);

  const openClass = (id: string) => { setSelectedClass(id); setClassTab("students"); setSection("class"); setSidebarOpen(false); window.scrollTo({ top: 0 }); };
  const openStudent = (s: Student) => { setSelectedStudent(s); setShowMessage(false); };
  const toggleReveal = (id: string) => setRevealed((p) => ({ ...p, [id]: !p[id] }));
  const copyText = (text: string, okMsg = "تم النسخ") => {
    const ta = document.createElement("textarea");
    ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select();
    let ok = false; try { ok = document.execCommand("copy"); } catch { ok = false; }
    document.body.removeChild(ta);
    flash(ok ? okMsg : "تعذّر النسخ — انسخ النص الظاهر يدوياً");
  };
  const copyPhone = (normalized: string) => {
    const local = toLocalPhone(normalized);
    copyText(local, "تم نسخ الرقم");
  };
  const waLink = (phone: string | undefined, text: string) => phone ? `https://wa.me/${phone}?text=${encodeURIComponent(text)}` : "";

  // ---------- Weekly report helpers ----------
  const weeklyStudent = roster.find(s => s.id === weeklyStudentId) || roster[0] || ALL_STUDENTS[0];
  const weeklyClassStudents = roster.filter(s => s.className === weeklyClass);
  const getPresentAbsent = (sid: string) => {
    const absent = weeklyAbsent[sid] ?? (attendance[sid] === "غائب" ? 1 : 0);
    const present = weeklyPresent[sid] ?? (5 - absent);
    return { present, absent };
  };
  const weeklyMessageFor = (s: Student) => {
    const g = grades[s.id] || { h: 0, p: 0, b: 0 };
    const { present, absent } = getPresentAbsent(s.id);
    const note = notes[s.id] || "واصل تقدمه الجميل، ونحن فخورون به.";
    const growth = growthNotes[s.id] ? `\nسجل النمو: ${growthNotes[s.id]}` : "";
    return `السلام عليكم ورحمة الله، هذا تقرير ابنكم ${s.name} لهذا الأسبوع من فصل ${s.className} في مدرسة الربيع بن زياد الابتدائية.\n\n📍 الحضور: حضر ${present} من 5 أيام، وغاب ${absent} ${absent === 1 ? "يوم" : "أيام"}.\n✏️ الواجبات: ${g.h} من 10.\n🙋 المشاركة: ${g.p} من 10.\n💛 السلوك: ${g.b} من 10.\n📝 ملاحظة المعلم: ${note}${growth}\n\nشكراً لكم على متابعتكم ودعمكم له في البيت، ونواصل معه معاً بإذن الله.\nمع خالص التقدير، أ. عبدالعزيز`;
  };
  const absenceMessageFor = (s: Student) => `السلام عليكم ورحمة الله،\nاليوم ابنكم ${s.name} من فصل ${s.className} غائب، طمنونا عليه، ونسأل الله له الشفاء والعافية إن كان مريضاً.\nإذا كان لديه أي ظرف، يسعدنا أن تبلغونا، وسنعوضه ما فاته بإذن الله.\nمع خالص التقدير، أ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`;
  const congratsMessageFor = (s: Student) => `🎉 فخورون بك يا بطل، أنت ابن الأسبوع 🎉\n\nمبارك لابنكم ${s.name} من فصل ${s.className} — اختير ابن الأسبوع في مدرسة الربيع بن زياد الابتدائية لحضوره الكامل واجتهاده ومشاركته الرائعة وأخلاقه الجميلة.\n\nفخورون بك يا بطل، أنت ابن الأسبوع، وواصل تألقك فأنت قدوة لزملائك.\nمع خالص التقدير، أ. عبدالعزيز`;
  const planMessageFor = (s: Student) => {
    const kindLabel = planKind === "إثرائية" ? "الخطة الإثرائية" : "الخطة العلاجية";
    return `السلام عليكم ورحمة الله،\nأشارككم ${kindLabel} لابنكم ${s.name} من فصل ${s.className} — مهارة: ${planSkill}.\n\n🎯 الهدف: ${planGoal}\n📌 الأنشطة:\n${planActivities.split("\n").filter(Boolean).map((a, i) => `${i + 1}. ${a}`).join("\n")}\n📄 ورقة العمل: ${planWorksheet}\n🏠 كيف تساعدونه في البيت: ${planHome}\n⏳ المدة: أسبوعان — الحالة: ${planStatus} — التقدم: ${planProgress}%\n\nشكراً لتعاونكم، ونواصل معه في الفصل بإذن الله.\nأ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`;
  };

  const saveNoteFor = async (studentId: string) => {
    const s = roster.find(x => x.id === studentId); if (!s) return;
    setBusy(true);
    const val = { studentId: s.id, studentName: s.name, class: s.className, note: notes[s.id] || "" };
    try {
      if (noteRecordIds[s.id]) await api("records.replace", { collection: "student_notes", id: noteRecordIds[s.id], value: val });
      else { const created: any = await api("records.create", { collection: "student_notes", value: val, idempotency_key: `note-${s.id}-${Date.now()}` }); if (created?.id) setNoteRecordIds((p) => ({ ...p, [s.id]: created.id })); }
      flash("تم حفظ ملاحظة المعلم");
    } catch { flash("تم حفظ الملاحظة داخل الجلسة"); }
    setBusy(false);
  };
  const savePlan = async () => {
    if (!selectedStudent) return;
    setBusy(true);
    const val: PlanValue & { studentId: string; studentName: string; className: string } = { studentId: selectedStudent.id, studentName: selectedStudent.name, className: selectedStudent.className, skill: planSkill, kind: planKind, goal: planGoal, activities: planActivities.split("\n").map(x => x.trim()).filter(Boolean), worksheet: planWorksheet, homeHelp: planHome, status: planStatus, progress: planProgress };
    try {
      if (planRecordIds[selectedStudent.id]) await api("records.replace", { collection: "student_plans", id: planRecordIds[selectedStudent.id], value: val });
      else { const created: any = await api("records.create", { collection: "student_plans", value: val, idempotency_key: `plan-${selectedStudent.id}-${Date.now()}` }); if (created?.id) setPlanRecordIds((p) => ({ ...p, [selectedStudent.id]: created.id })); }
      setPlans((p) => ({ ...p, [selectedStudent.id]: val }));
      flash("تم حفظ الخطة");
    } catch { setPlans((p) => ({ ...p, [selectedStudent.id]: val })); flash("تم حفظ الخطة داخل الجلسة"); }
    setBusy(false);
  };
  const saveGrowth = async () => {
    if (!selectedStudent) return;
    setBusy(true);
    const val = { studentId: selectedStudent.id, studentName: selectedStudent.name, className: selectedStudent.className, text: growthNotes[selectedStudent.id] || "" };
    try {
      if (growthIds[selectedStudent.id]) await api("records.replace", { collection: "growth_notes", id: growthIds[selectedStudent.id], value: val });
      else { const created: any = await api("records.create", { collection: "growth_notes", value: val, idempotency_key: `growth-${selectedStudent.id}-${Date.now()}` }); if (created?.id) setGrowthIds((p) => ({ ...p, [selectedStudent.id]: created.id })); }
      flash("تم حفظ سجل النمو");
    } catch { flash("تم حفظ سجل النمو داخل الجلسة"); }
    setBusy(false);
  };
  const awardMedal = async () => {
    const s = roster.find(x => x.id === honorStudentId); if (!s) return;
    const medal = MEDALS.find(m => m.id === honorMedalPick)!;
    const val = { studentId: s.id, studentName: s.name, className: s.className, medal: medal.id, date: new Date().toLocaleDateString("ar-SA") };
    setBusy(true);
    try {
      const created: any = await api("records.create", { collection: "honor_awards", value: val, idempotency_key: `honor-${s.id}-${medal.id}-${Date.now()}` });
      setAwards((p) => [{ id: created?.id || `honor-${Date.now()}`, ...val }, ...p]);
      flash(`مبارك! حصل ${s.name} على ${medal.label}`);
    } catch { setAwards((p) => [{ id: `local-${Date.now()}`, ...val }, ...p]); flash("أُضيف الوسام داخل الجلسة"); }
    setBusy(false);
  };
  const saveSonOfWeek = async (s: Student, reason: string) => {
    const val = { studentId: s.id, studentName: s.name, className: s.className, date: new Date().toLocaleDateString("ar-SA"), reason };
    setBusy(true);
    try {
      const created: any = await api("records.create", { collection: "son_of_week", value: val, idempotency_key: `son-${s.id}-${Date.now()}` });
      setSonHistory((p) => [{ id: created?.id || `son-${Date.now()}`, ...val }, ...p]);
      flash(`تم اختيار ${s.name} ابن الأسبوع`);
    } catch { setSonHistory((p) => [{ id: `local-${Date.now()}`, ...val }, ...p]); flash("تم اختيار ابن الأسبوع داخل الجلسة"); }
    setBusy(false);
  };

  const saveAttendance = async () => {
    setBusy(true); setSaveInfo("");
    try {
      await api("records.create", { collection: "attendance", value: { classId: selectedClass, className: cls.name, date: new Date().toISOString().slice(0, 10), present: attCounts.p, absent: attCounts.a, late: attCounts.l, entries: attendance }, idempotency_key: `att-${selectedClass}-${new Date().toISOString().slice(0, 10)}` });
      flash("تم حفظ حضور اليوم بنجاح"); setSaveInfo("تم الحفظ في السجلات الدائمة.");
    } catch (e: any) { setSaveInfo("تعذّر الحفظ الدائم: " + (e?.message || "حاول مجدداً")); flash("تم تسجيل الحضور داخل الجلسة"); }
    setBusy(false);
  };
  const saveGrades = async () => {
    setBusy(true);
    try {
      const rows = classStudents.map((s) => ({ student: s.name, ...grades[s.id], total: grades[s.id].h + grades[s.id].p + grades[s.id].b }));
      await api("records.create", { collection: "followup", value: { classId: selectedClass, date: new Date().toISOString().slice(0, 10), rows }, idempotency_key: `follow-${selectedClass}-${Date.now()}` });
      flash("تم حفظ سجل المتابعة"); setSaveInfo("تم حفظ درجات المتابعة في السجلات.");
    } catch { setSaveInfo("تعذّر الحفظ الدائم — الدرجات محفوظة داخل الجلسة."); flash("تم حفظ الدرجات داخل الجلسة"); }
    setBusy(false);
  };
  const saveNote = async () => {
    if (!selectedStudent) return;
    await saveNoteFor(selectedStudent.id);
  };
  const addEvidence = async () => {
    if (!evTitle.trim()) { flash("اكتب عنوان الشاهد أولاً"); return; }
    setBusy(true);
    const val = { title: evTitle.trim(), desc: evDesc.trim() || "شاهد أداء مضاف من لوحة المعلم.", kind: evKind, date: "اليوم" };
    try {
      const created: any = await api("records.create", { collection: "evidence", value: val, idempotency_key: `ev-${Date.now()}` });
      setEvidence((p) => [{ id: created?.id || `ev-${Date.now()}`, ...val }, ...p]);
      flash("تمت إضافة الشاهد وحفظه");
    } catch {
      setEvidence((p) => [{ id: `local-${Date.now()}`, ...val, pending: true }, ...p]);
      flash("أُضيف الشاهد داخل الجلسة — تعذّر الحفظ الدائم");
    }
    setEvTitle(""); setEvDesc(""); setShowEvidenceForm(false); setBusy(false);
  };
  const autoFillWeek = () => {
    setWeek({ "الأحد": [{ time: "08:00", title: "الجمع حتى 20 — أنشطة تفاعلية", cls: "اول/4" }, { time: "10:00", title: "أجزاء النبات وتجربة عملية", cls: "ثالث/1" }], "الاثنين": [{ time: "08:00", title: "القراءة الجهرية والتعبير", cls: "ثالث/2" }, { time: "09:00", title: "الضرب كجمع متكرر", cls: "ثالث/3" }], "الثلاثاء": [{ time: "08:00", title: "الطرح بالاستلاف", cls: "ثالث/3" }, { time: "10:00", title: "مراجعة الكسور", cls: "اول/4" }], "الأربعاء": [{ time: "08:00", title: "دورة حياة النبات", cls: "ثالث/1" }, { time: "09:00", title: "الإملاء المنظور", cls: "ثالث/2" }], "الخميس": [{ time: "08:00", title: "مراجعة عامة وأنشطة إثرائية", cls: "اول/4" }, { time: "10:00", title: "تقويم أسبوعي", cls: "ثالث/3" }] });
    flash("تم ملء التحضير الأسبوعي تلقائياً");
  };
  const guardianMessage = selectedStudent ? (
    messageKind === "تقدير"
      ? `السلام عليكم ورحمة الله،\nأخاطبكم بكل تقدير عن ابني ${selectedStudent.name} من فصل ${selectedStudent.className}.\nيسعدني أن أشارككم أن ابني أظهر اليوم اجتهاداً ومشاركة جميلة، وأنا فخور به وبأخلاقه داخل الفصل.\nشكراً لكم على متابعتكم ودعمكم له في البيت.\nمع خالص التقدير، أ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`
      : messageKind === "متابعة واجب"
        ? `السلام عليكم ورحمة الله،\nأتواصل معكم بخصوص ابني ${selectedStudent.name} من فصل ${selectedStudent.className}.\nأرجو متابعة واجبه معه اليوم وتشجيعه على إتمامه بهدوء، وسأتابع معه غداً في الفصل بإذن الله.\nشكراً لتعاونكم الدائم.\nأ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`
        : `السلام عليكم ورحمة الله،\nأحببت أن أتواصل معكم حول ابني ${selectedStudent.name} من فصل ${selectedStudent.className}، للاطمئنان عليه وتبادل الملاحظات بما يخدم مصلحته.\nيسعدني تواصلكم مع المدرسة في الوقت المناسب لكم.\nمع خالص التقدير، أ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`
  ) : "";

  // ---------- Madrasati sync logic ----------
  const reloadRosterRecords = async () => {
    const [rs, ar, meta]: any[] = await Promise.all([
      api("records.list", { collection: "roster_students" }),
      api("records.list", { collection: "archived_students" }),
      api("records.list", { collection: "roster_sync_meta" }),
    ]);
    const rMap: Record<string, string> = {}; const rList: Student[] = [];
    (rs?.records || []).forEach((rec: any) => { if (rec?.value?.name) { rList.push({ ...rec.value, id: rec.value.id || rec.id, className: rec.value.className || rec.value.class }); rMap[rec.value.id || rec.id] = rec.id; } });
    const aMap: Record<string, string> = {}; const aList: Student[] = [];
    (ar?.records || []).forEach((rec: any) => { if (rec?.value?.name) { aList.push({ ...rec.value, id: rec.value.id || rec.id, className: rec.value.className || rec.value.class }); aMap[rec.value.id || rec.id] = rec.id; } });
    if (rList.length) { setRoster(rList); setRosterRecordIds(rMap); }
    if (aList.length) { setArchived(aList); setArchivedRecordIds(aMap); }
    const metas = (meta?.records || []).map((r: any) => r.value).filter(Boolean).sort((a: any, b: any) => String(b?.updatedAt || "").localeCompare(String(a?.updatedAt || "")));
    if (metas[0]?.updatedAt) setLastSyncAt(metas[0].updatedAt);
  };
  useEffect(() => { reloadRosterRecords().catch(() => {}); }, []);
  const applyPreview = (rows: RosterRow[], fileName: string) => {
    const dedup = rows.filter((r, i) => rows.findIndex((x) => normName(x.name) === normName(r.name)) === i);
    const preview = buildRosterPreview(roster, dedup);
    setSyncIncoming(dedup); setSyncPreview(preview); setSyncFileName(fileName); setSyncError("");
    const addSel: Record<string, boolean> = {}; preview.added.forEach((r) => { addSel[normName(r.name)] = true; });
    const movSel: Record<string, boolean> = {}; preview.moved.forEach((m) => { movSel[m.student.id] = true; });
    const missSel: Record<string, boolean> = {}; preview.missing.forEach((s) => { missSel[s.id] = true; });
    setSelectedAdded(addSel); setSelectedMoved(movSel); setSelectedMissing(missSel); setSyncResult(null);
  };
  const handleRosterFile = async (file: File | undefined | null) => {
    if (!file) return;
    setSyncParsing(true); setSyncError(""); setSyncResult(null);
    try {
      const name = file.name.toLowerCase();
      let rows: RosterRow[] = [];
      if (name.endsWith(".csv") || name.endsWith(".txt")) rows = parseCsvText(await file.text());
      else if (name.endsWith(".xlsx") || name.endsWith(".xls")) rows = await parseRosterXlsx(await file.arrayBuffer());
      else { setSyncError("صيغة غير مدعومة — ارفع ملف Excel (.xlsx) أو CSV من مدرستي أو نور."); setSyncParsing(false); return; }
      if (!rows.length) { setSyncError("لم نجد طلاباً في الملف — تأكد أن الملف يحتوي أعمدة: اسم الطالب والفصل ورقم الطالب إن وجد."); setSyncParsing(false); return; }
      applyPreview(rows, file.name);
      flash(`تمت قراءة ${rows.length} طالباً من الملف — راجع المعاينة قبل الحفظ`);
    } catch { setSyncError("تعذّرت قراءة الملف — تأكد أنه تصدير Excel أو CSV سليم من مدرستي أو نور."); }
    setSyncParsing(false);
  };
  const demoPreview = () => {
    const first = roster[0]; const second = roster[1];
    const rows: RosterRow[] = roster.map((s) => ({ name: s.name, className: s.className, guardian: s.guardian }));
    if (first) { const other = CLASS_ORDER.find((c) => c !== first.className) || "ثالث/1"; rows[0] = { name: first.name, className: other, guardian: first.guardian }; }
    const filtered = second ? rows.filter((r) => normName(r.name) !== normName(second.name)) : rows;
    filtered.push({ name: "طالب جديد تجريبي", className: "اول/4", guardian: "ولي أمر تجريبي" });
    filtered.push({ name: "طالبة جديدة تجريبية", className: "ثالث/2", guardian: "ولي أمر تجريبي" });
    applyPreview(filtered, "معاينة تجريبية — ملف مدرستي");
    flash("هذه معاينة تجريبية — لن يُحفظ شيء حتى تضغط تأكيد التحديث");
  };
  const confirmSync = async () => {
    if (!syncPreview) return;
    const addedRows = syncPreview.added.filter((r) => selectedAdded[normName(r.name)]);
    const movedRows = syncPreview.moved.filter((m) => selectedMoved[m.student.id]);
    const archivedRows = syncPreview.missing.filter((s) => selectedMissing[s.id]);
    if (!addedRows.length && !movedRows.length && !archivedRows.length) { flash("اختر طالباً واحداً على الأقل من المعاينة"); return; }
    type Op = { kind: "add" | "move" | "archive"; row?: RosterRow; student?: Student; to?: string };
    const ops: Op[] = [...addedRows.map((row) => ({ kind: "add" as const, row })), ...movedRows.map((m) => ({ kind: "move" as const, student: m.student, to: m.to })), ...archivedRows.map((student) => ({ kind: "archive" as const, student }))];
    const createRow = async (op: Op) => {
      if (op.kind === "add" && op.row) {
        const val = { id: `roster-${Date.now()}-${normName(op.row.name)}`, name: op.row.name, class: op.row.className, className: op.row.className, guardian: op.row.guardian || "ولي الأمر", school: "الربيع بن زياد الابتدائية", status: "منتظم", studentNo: op.row.studentNo || "" };
        await api("records.create", { collection: "roster_students", value: val, idempotency_key: `roster-add-${normName(op.row.name)}-${op.row.className}` });
      } else if (op.kind === "move" && op.student && op.to) {
        const val = { id: op.student.id, name: op.student.name, class: op.to, className: op.to, guardian: op.student.guardian, school: op.student.school, status: op.student.status };
        const recId = rosterRecordIds[op.student.id];
        if (recId) await api("records.replace", { collection: "roster_students", id: recId, value: val });
        else await api("records.create", { collection: "roster_students", value: val, idempotency_key: `roster-move-${op.student.id}-${op.to}` });
      } else if (op.kind === "archive" && op.student) {
        const val = { id: op.student.id, name: op.student.name, class: op.student.className, className: op.student.className, guardian: op.student.guardian, school: op.student.school, status: "مؤرشف", archivedAt: new Date().toLocaleDateString("ar-SA") };
        await api("records.create", { collection: "archived_students", value: val, idempotency_key: `archived-${op.student.id}` });
        const recId = rosterRecordIds[op.student.id];
        if (recId) await api("records.delete", { collection: "roster_students", id: recId });
      }
    };
    setSyncConfirming(true); setBusy(true);
    let saved = 0; let error: string | null = null;
    try { for (const row of ops) { await createRow(row); saved += 1; } } catch (e) { error = e instanceof Error ? e.message : String(e); }
    let reloadError: string | null = null;
    try {
      if (!error) {
        const stamp = new Date().toLocaleDateString("ar-SA") + " — " + new Date().toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit" });
        await api("records.create", { collection: "roster_sync_meta", value: { updatedAt: stamp, added: addedRows.length, moved: movedRows.length, archived: archivedRows.length, fileName: syncFileName }, idempotency_key: `sync-meta-${Date.now()}` });
        setLastSyncAt(stamp);
      }
      await reloadRosterRecords();
      // تحديث محلي فوري حتى لو كان الحفظ في المعاينة غير متاح — مع الحفاظ على السجلات السابقة
      if (error) {
        const next = [...roster];
        movedRows.forEach((m) => { const idx = next.findIndex((s) => s.id === m.student.id); if (idx >= 0) next[idx] = { ...next[idx], className: m.to, class: m.to }; });
        const withoutArchived = next.filter((s) => !archivedRows.some((a) => a.id === s.id));
        const newStudents: Student[] = addedRows.map((r, i) => ({ id: `new-${Date.now()}-${i}`, name: r.name, class: r.className, className: r.className, guardian: r.guardian || "ولي الأمر", school: "الربيع بن زياد الابتدائية", status: "منتظم" }));
        setRoster([...withoutArchived, ...newStudents]);
        setArchived((p) => [...archivedRows, ...p]);
      } else {
        // بعد إعادة التحميل، طبّق التغييرات محلياً إذا لم تظهر بعد (المعاينة بلا خادم)
        const hasNew = addedRows.every((r) => roster.some((s) => normName(s.name) === normName(r.name)));
        if (!hasNew) {
          setRoster((prev) => {
            const movedPrev = prev.map((s) => { const m = movedRows.find((x) => x.student.id === s.id); return m ? { ...s, className: m.to, class: m.to } : s; });
            const filteredPrev = movedPrev.filter((s) => !archivedRows.some((a) => a.id === s.id));
            const news: Student[] = addedRows.filter((r) => !filteredPrev.some((s) => normName(s.name) === normName(r.name))).map((r, i) => ({ id: `new-${Date.now()}-${i}`, name: r.name, class: r.className, className: r.className, guardian: r.guardian || "ولي الأمر", school: "الربيع بن زياد الابتدائية", status: "منتظم" }));
            return [...filteredPrev, ...news];
          });
          setArchived((p) => [...archivedRows.filter((a) => !p.some((x) => x.id === a.id)), ...p]);
        }
      }
    } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setSyncResult({ saved, remaining: ops.length - saved, error, reloadError });
    setSyncConfirming(false); setBusy(false);
    if (!error) {
      flash(`تم تحديث القائمة: +${addedRows.length} جديد و ${movedRows.length} منقول و ${archivedRows.length} مؤرشف`);
      setSyncPreview(null); setSyncIncoming([]);
    } else flash("تم حفظ بعض التغييرات داخل الجلسة — راجع رسالة الخطأ");
  };
  const restoreArchivedStudent = async (s: Student) => {
    setBusy(true);
    try {
      const val = { id: s.id, name: s.name, class: s.className, className: s.className, guardian: s.guardian, school: s.school, status: "منتظم" };
      await api("records.create", { collection: "roster_students", value: val, idempotency_key: `restore-${s.id}` });
      const recId = archivedRecordIds[s.id];
      if (recId) await api("records.delete", { collection: "archived_students", id: recId });
      flash(`تمت استعادة ${s.name} إلى فصل ${s.className}`);
    } catch { flash("تمت الاستعادة داخل الجلسة"); }
    setArchived((p) => p.filter((x) => x.id !== s.id));
    setRoster((p) => p.some((x) => x.id === s.id) ? p : [...p, s]);
    setBusy(false);
  };

  const nav = [
    { id: "sync", label: "تحديث مدرستي", icon: RefreshCw },
    { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
    { id: "classes", label: "أبنائي", icon: GraduationCap },
    { id: "weekly-report", label: "التقرير الأسبوعي", icon: FileText },
    { id: "honor", label: "لوحة الشرف", icon: Trophy },
    { id: "son-week", label: "ابن الأسبوع", icon: Crown },
    { id: "alerts", label: "تنبيه مبكر", icon: AlertTriangle },
    { id: "draw", label: "القرعة العادلة", icon: Shuffle },
    { id: "contacts", label: "التواصل مع أولياء الأمور", icon: Phone },
    { id: "attendance", label: "الحضور والغياب", icon: ClipboardCheck },
    { id: "followup", label: "سجلات المتابعة", icon: BookOpen },
    { id: "questions", label: "بنك الأسئلة", icon: HelpCircle },
    { id: "weekly", label: "التحضير الأسبوعي", icon: CalendarDays },
    { id: "reports", label: "التقارير", icon: FileText },
    { id: "evidence", label: "شواهد الأداء", icon: Award },
  ];

  const selectedPhone = selectedStudent ? excelPhones[selectedStudent.id] : undefined;

  // ---------- Derived for new sections ----------
  const weeklyFilteredForSearch = useMemo(() => {
    const q = weeklySearch.trim();
    if (!q) return weeklyClassStudents;
    return weeklyClassStudents.filter(s => s.name.includes(q) || s.guardian.includes(q));
  }, [weeklySearch, weeklyClass]);
  const batchFiltered = useMemo(() => {
    const q = batchSearch.trim();
    if (!q) return weeklyClassStudents;
    return weeklyClassStudents.filter(s => s.name.includes(q) || s.guardian.includes(q));
  }, [batchSearch, weeklyClass]);

  const honorFiltered = useMemo(() => awards.filter(a => (honorClass === "الكل" || a.className === honorClass) && (honorMedal === "الكل" || a.medal === honorMedal)), [awards, honorClass, honorMedal]);
  const honorCounts = useMemo(() => {
    const m: Record<string, number> = {};
    awards.forEach(a => { m[a.studentId] = (m[a.studentId] || 0) + 1; });
    return m;
  }, [awards]);
  const topHonor = useMemo(() => Object.entries(honorCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([sid, count]) => ({ student: ALL_STUDENTS.find(s => s.id === sid), count })), [honorCounts]);

  const evalScore = (sid: string) => {
    const e = evaluations[sid];
    const map: Record<string, number> = { "ممتاز": 3, "جيد": 2, "يحتاج دعم": 1 };
    if (!e) {
      const g = grades[sid] || { h: 8, p: 8, b: 8 };
      const toLabel = (v: number) => v >= 9 ? "ممتاز" : v >= 7 ? "جيد" : "يحتاج دعم";
      return map[toLabel(g.h)] + map[toLabel(g.p)] + map[toLabel(g.b)] + (attendance[sid] === "غائب" ? 1 : 3);
    }
    return map[e.att] + map[e.hw] + map[e.part] + map[e.beh];
  };
  const sonClassStudents = ALL_STUDENTS.filter(s => s.className === sonClass);
  const autoSon = useMemo(() => {
    const sorted = [...sonClassStudents].sort((a, b) => evalScore(b.id) - evalScore(a.id));
    return sorted[0];
  }, [sonClass, evaluations, grades, attendance]);
  const sonCandidate = sonCandidateId ? ALL_STUDENTS.find(s => s.id === sonCandidateId) : autoSon;

  const alertStudents = useMemo(() => {
    return roster.map(s => {
      const g = grades[s.id] || { h: 0, p: 0, b: 0 };
      const total = g.h + g.p + g.b;
      const reasons: string[] = [];
      if (attendance[s.id] === "غائب") reasons.push("غائب اليوم — يحتاج اطمئناناً سريعاً");
      if (g.p <= 5) reasons.push("تراجعت مشاركته (5 من 10 أو أقل)");
      if (g.h <= 5) reasons.push("واجباته غير مكتملة (5 من 10 أو أقل)");
      if (total <= 15) reasons.push("مجموع المتابعة منخفض — يحتاج دعماً");
      if (getPresentAbsent(s.id).absent >= 3) reasons.push("غاب 3 مرات أو أكثر هذا الأسبوع");
      return { s, reasons, total };
    }).filter(x => x.reasons.length > 0);
  }, [grades, attendance, weeklyAbsent, weeklyPresent]);
  const alertFiltered = useMemo(() => {
    const q = alertSearch.trim();
    if (!q) return alertStudents;
    return alertStudents.filter(x => x.s.name.includes(q) || x.s.guardian.includes(q));
  }, [alertSearch, alertStudents]);

  const drawClassStudents = roster.filter(s => s.className === drawClass);
  const doDraw = () => {
    let pool = drawPool.length ? [...drawPool] : drawClassStudents.map(s => s.id);
    if (!pool.length) { flash("انتهت الجولة — ابدأ جولة جديدة"); return; }
    setDrawSpinning(true);
    let ticks = 0;
    const iv = setInterval(() => {
      const rnd = drawClassStudents[Math.floor(Math.random() * drawClassStudents.length)];
      setCurrentDraw(rnd);
      ticks++;
      if (ticks > 10) {
        clearInterval(iv);
        const idx = Math.floor(Math.random() * pool.length);
        const pickedId = pool[idx];
        const picked = ALL_STUDENTS.find(s => s.id === pickedId)!;
        setCurrentDraw(picked);
        setDrawPool(pool.filter(id => id !== pickedId));
        setDrawHistory(h => [picked, ...h]);
        setDrawSpinning(false);
        flash(`دور ${picked.name} للمشاركة الآن`);
      }
    }, 90);
  };

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh", backgroundImage: `linear-gradient(rgba(255,255,255,0.90), rgba(255,255,255,0.90)), url(${schoolImageUrl})`, backgroundSize: "cover", backgroundPosition: "center", backgroundRepeat: "no-repeat", backgroundAttachment: "fixed" }} dir="rtl">
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-30 border-b border-[var(--line)] bg-white/80 backdrop-blur-md">
        <div className="mx-auto max-w-[1500px] px-3 sm:px-5 py-3 flex flex-wrap items-center gap-2 sm:gap-4">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden w-10 h-10 grid place-items-center rounded-xl border border-[var(--line)]" aria-label="فتح القائمة"><Menu size={20} /></button>
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-[var(--primary)] text-white grid place-items-center font-black text-xl shrink-0 shadow-lg shadow-violet-300">و</div>
            <div className="min-w-0">
              <p className="font-black text-[17px] sm:text-[20px] leading-5 truncate">متابعتي <span className="text-[var(--primary)]">لأبنائي</span></p>
              <p className="text-[11px] text-[var(--muted)] font-bold">أبنائي طلابي .. وطلابي أبنائي</p>
            </div>
          </div>
          <div className="hidden md:flex flex-1 max-w-md mx-auto items-center gap-2 bg-[var(--bg)] border border-[var(--line)] rounded-full px-4 py-2.5">
            <Search size={18} className="text-[var(--muted)] shrink-0" />
            <input value={search} onChange={(e) => { setSearch(e.target.value); if (e.target.value) setSection("search"); }} placeholder="ابحث عن ابني بالاسم…" className="bg-transparent flex-1 text-sm font-medium min-w-0" />
          </div>
          <div className="ms-auto flex items-center gap-2">
            <button onClick={() => { setShowNewSession(true); }} className="hidden sm:flex items-center gap-1.5 bg-[var(--green)] text-white px-3.5 py-2.5 rounded-full text-[13px] font-extrabold"><Plus size={16} /> حصة جديدة</button>
            <button onClick={() => setShowNewPrep(true)} className="flex items-center gap-1.5 bg-[var(--primary)] text-white px-3.5 py-2.5 rounded-full text-[13px] font-extrabold"><Sparkles size={16} /> <span className="hidden sm:inline">تحضير جديد</span><span className="sm:hidden">تحضير</span></button>
            <button onClick={() => flash("لا توجد تنبيهات جديدة — كل شيء على ما يرام")} className="relative w-10 h-10 grid place-items-center rounded-full border border-[var(--line)]" aria-label="التنبيهات"><Bell size={19} /><span className="absolute top-2 left-2 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white" /></button>
            <button onClick={() => { setSlide(0); setShowPresentation(true); setShowTeacherCard(false); setSidebarOpen(false); }} className="flex items-center gap-1.5 bg-[#F59E0B] text-white px-3 sm:px-4 py-2.5 rounded-full text-[12px] sm:text-[13px] font-extrabold shadow-lg shadow-amber-300 border-2 border-amber-300" aria-label="وضع العرض للإدارة"><Crown size={16} /> وضع العرض <span className="hidden sm:inline">للإدارة</span></button>
            <button onClick={() => { setSection("sync"); setSidebarOpen(false); window.scrollTo({ top: 0 }); }} className="flex items-center gap-1.5 bg-[var(--green)] text-white px-3 sm:px-4 py-2.5 rounded-full text-[12px] sm:text-[13px] font-extrabold shadow-lg shadow-emerald-200" aria-label="تحديث مدرستي"><RefreshCw size={16} /> تحديث مدرستي</button>
            <div className="relative flex items-center gap-2 ps-1">
              <button onClick={() => setShowTeacherCard((v) => !v)} className="flex items-center gap-2 rounded-full" aria-label="ملف المعلم" aria-expanded={showTeacherCard}>
                <img src={teacherPhotoUrl} alt="صورة أ. عبدالعزيز" className="w-[52px] h-[52px] rounded-full object-cover border-[3px] border-white shadow-md" />
                <span className="hidden xl:block leading-tight text-start"><span className="block font-extrabold text-[13px]">أ. عبدالعزيز</span><span className="block text-[11px] text-[var(--muted)]">مدرسة الربيع بن زياد الابتدائية</span></span>
              </button>
              {showTeacherCard && <>
                <button aria-label="إغلاق بطاقة المعلم" onClick={() => setShowTeacherCard(false)} className="fixed inset-0 z-40 cursor-default" />
                <div className="absolute top-full left-0 z-50 mt-2 w-[280px] card p-4 pop">
                  <div className="flex items-start justify-between gap-2">
                    <img src={teacherPhotoUrl} alt="صورة أ. عبدالعزيز" className="w-20 h-20 rounded-full object-cover border-[3px] border-white shadow-md" />
                    <button onClick={() => setShowTeacherCard(false)} className="w-8 h-8 grid place-items-center rounded-full bg-[var(--bg)]" aria-label="إغلاق"><X size={16} /></button>
                  </div>
                  <p className="font-black text-[17px] mt-3">أ. عبدالعزيز</p>
                  <p className="text-[12.5px] text-[var(--muted)] font-bold mt-0.5">مدرسة الربيع بن زياد الابتدائية</p>
                  <div className="grid grid-cols-2 gap-2 mt-4 text-center">
                    <div className="bg-[var(--primary-soft)] rounded-2xl p-3"><p className="font-black text-[20px] num leading-none">134</p><p className="text-[12px] font-bold text-[var(--muted)] mt-1">عدد الأبناء</p></div>
                    <div className="bg-[var(--green-soft)] rounded-2xl p-3"><p className="font-black text-[20px] num leading-none">4</p><p className="text-[12px] font-bold text-[var(--muted)] mt-1">عدد الفصول</p></div>
                  </div>
                </div>
              </>}
            </div>
          </div>
        </div>
        {backendNote && <p className="px-4 pb-2 text-[12px] text-amber-700 font-bold text-center">{backendNote}</p>}
      </header>

      <div className="mx-auto max-w-[1500px] flex items-start gap-5 px-3 sm:px-5 py-4 sm:py-6">
        <aside className="hidden lg:block w-[248px] shrink-0 sticky top-[86px]">
          <div className="rounded-[22px] border border-[var(--line)] p-3 shadow-[var(--shadow)] bg-white/80 backdrop-blur-md">
            <button onClick={() => setShowTeacherCard(true)} className="w-full flex items-center gap-3 rounded-2xl bg-[var(--primary-soft)] p-3 text-start" aria-label="فتح ملف المعلم">
              <img src={teacherPhotoUrl} alt="صورة أ. عبدالعزيز" className="w-14 h-14 rounded-full object-cover border-[3px] border-white shadow-md shrink-0" />
              <span className="min-w-0"><span className="block font-black text-[14px] truncate">أ. عبدالعزيز</span><span className="block text-[11px] text-[var(--muted)] leading-5">مدرسة الربيع بن زياد الابتدائية</span><span className="block text-[11px] font-extrabold text-[var(--primary)] mt-0.5">134 ابناً • 4 فصول</span></span>
            </button>
            <button onClick={() => setSection("sync")} className="mt-3 w-full flex items-center justify-center gap-2 bg-[var(--green)] text-white px-3 py-3 rounded-2xl text-[14px] font-extrabold shadow-lg shadow-emerald-200"><RefreshCw size={18} /> تحديث مدرستي</button>
            <p className="px-2 pt-3 pb-2 text-[11px] font-black tracking-wide text-[var(--muted)]">القائمة الرئيسية</p>
            <nav className="space-y-1">
              {nav.map((n) => { const Icon = n.icon; const active = section === n.id || (n.id === "classes" && section === "class"); return <button key={n.id} onClick={() => setSection(n.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[14px] font-extrabold ${active ? "bg-[var(--primary)] text-white shadow-lg shadow-violet-200" : "hover:bg-[var(--bg)] text-[var(--ink)]"}`}><Icon size={19} /><span>{n.label}</span>{active && <ChevronLeft size={16} className="ms-auto" />}</button>; })}
            </nav>
            <div className="mt-4 rounded-2xl bg-[var(--primary-soft)] p-4">
              <div className="flex items-center gap-2 font-black text-[var(--primary)]"><Heart size={17} /> رسالة اليوم</div>
              <p className="text-[12.5px] leading-6 mt-2 font-medium text-[var(--ink)]">أبنائي طلابي .. وطلابي أبنائي — كل متابعة صغيرة اليوم، تصنع فرقاً كبيراً في رحلتهم غداً.</p>
              <button onClick={() => setSection("weekly")} className="mt-3 w-full bg-white py-2 rounded-xl text-[12px] font-extrabold text-[var(--primary)] shadow-sm">عرض تحضير الأسبوع</button>
            </div>
          </div>
        </aside>

        {sidebarOpen && <div className="fixed inset-0 z-50 lg:hidden"><div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} /><div className="absolute top-0 right-0 bottom-0 w-[280px] bg-white/90 backdrop-blur-md p-4 overflow-y-auto pop"><div className="flex justify-between items-center mb-4"><b>القائمة</b><button onClick={() => setSidebarOpen(false)} className="w-9 h-9 grid place-items-center rounded-full bg-[var(--bg)]"><X size={18} /></button></div><button onClick={() => { setSidebarOpen(false); setShowTeacherCard(true); }} className="w-full flex items-center gap-3 rounded-2xl bg-[var(--primary-soft)] p-3 text-start mb-4" aria-label="فتح ملف المعلم"><img src={teacherPhotoUrl} alt="صورة أ. عبدالعزيز" className="w-14 h-14 rounded-full object-cover border-[3px] border-white shadow-md shrink-0" /><span className="min-w-0"><span className="block font-black text-[14px] truncate">أ. عبدالعزيز</span><span className="block text-[11px] text-[var(--muted)] leading-5">مدرسة الربيع بن زياد الابتدائية</span><span className="block text-[11px] font-extrabold text-[var(--primary)] mt-0.5">134 ابناً • 4 فصول</span></span></button><button onClick={() => { setSection("sync"); setSidebarOpen(false); }} className="w-full flex items-center justify-center gap-2 bg-[var(--green)] text-white px-3 py-3 rounded-2xl font-extrabold mb-3"><RefreshCw size={18} /> تحديث مدرستي</button>{nav.map((n) => { const Icon = n.icon; return <button key={n.id} onClick={() => { setSection(n.id); setSidebarOpen(false); }} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl font-extrabold hover:bg-[var(--bg)]"><Icon size={19} />{n.label}</button>; })}</div></div>}

        <main className="flex-1 min-w-0 pb-10">
          {section === "dashboard" && <div className="space-y-5 pop">
            <section className="card p-5 sm:p-6 flex flex-wrap items-center gap-4 border-[var(--green)]/30 bg-[var(--green-soft)]">
              <span className="w-14 h-14 rounded-2xl bg-[var(--green)] text-white grid place-items-center shrink-0 shadow-lg shadow-emerald-200"><RefreshCw size={26} /></span>
              <div className="flex-1 min-w-[200px]">
                <h2 className="text-[22px] font-black leading-8">تحديث مدرستي</h2>
                <p className="text-[13.5px] text-[var(--muted)] leading-6 mt-1">حدّث قائمة أبنائك من ملف مدرستي — ادخل مدرستي من المتصفح وصدّر قائمة الطلاب Excel ثم ارفع الملف هنا، وراجع المعاينة قبل تأكيد التحديث.</p>
              </div>
              <button onClick={() => setSection("sync")} className="bg-[var(--green)] text-white px-5 py-3 rounded-full text-[13px] font-extrabold flex items-center gap-2 shadow-lg shadow-emerald-200"><RefreshCw size={16} /> تحديث مدرستي</button>
            </section>
            <section className="relative overflow-hidden rounded-[26px] border border-[var(--line)] shadow-[var(--shadow)]">
              <img src={schoolImageUrl} alt="مبنى مدرسة الربيع بن زياد الابتدائية" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-l from-white via-white/85 to-white/25" aria-hidden="true" />
              <div className="relative flex flex-wrap items-end justify-between gap-4 p-5 sm:p-7">
                <div className="max-w-[620px]">
                  <p className="text-[13px] font-bold text-[var(--muted)]">صباح الخير، أ. عبدالعزيز 👋</p>
                  <h1 className="text-[clamp(26px,4vw,38px)] font-black leading-tight mt-1">أهلاً بك في مدرسة الربيع بن زياد الابتدائية</h1>
                  <p className="text-[15px] font-extrabold text-[var(--primary)] mt-2">يومك مع <span>أبنائك</span> منظّم وجاهز.</p>
                  <p className="text-[13px] text-[var(--muted)] mt-1 font-bold">134 ابناً في 4 فصول • نسبة حضور اليوم {todayPct}%.</p>
                </div>
                <button onClick={() => { setSelectedClass("اول/4"); setSection("attendance"); }} className="bg-[var(--ink)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">ابدأ تسجيل حضور اليوم</button>
              </div>
            </section>
            <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
              <div className="card p-4"><span className="text-xl">🎓</span><p className="text-[clamp(28px,4vw,38px)] font-black mt-2 num leading-none">134</p><p className="font-extrabold text-[13px] mt-1">إجمالي أبنائي</p><p className="text-[12px] text-[var(--muted)]">طالباً في 4 فصول</p></div>
              <div className="card p-4"><span className="text-xl">🏫</span><p className="text-[clamp(28px,4vw,38px)] font-black mt-2 num leading-none">4</p><p className="font-extrabold text-[13px] mt-1">عدد الفصول</p><p className="text-[12px] text-[var(--muted)]">اول/4 • ثالث/1 • ثالث/2 • ثالث/3</p></div>
              <div className="card p-4"><span className="text-xl">📍</span><p className="font-black text-[17px] leading-6 mt-2">الربيع بن زياد الابتدائية</p><p className="font-extrabold text-[13px] mt-1">المدرسة</p><p className="text-[12px] text-[var(--muted)]">مدرسة أبنائي</p></div>
              <div className="card p-4"><span className="text-xl">✓</span><p className="text-[clamp(28px,4vw,38px)] font-black mt-2 num leading-none">{todayPct}%</p><p className="font-extrabold text-[13px] mt-1">نسبة الحضور اليوم</p><p className="text-[12px] text-[var(--muted)]">{totalAbsent} غائب • {totalLate} متأخر • تتحدّث مع التسجيل</p></div>
            </div>
            {/* New features quick access */}
            <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3">
              <button onClick={() => setSection("weekly-report")} className="card p-4 text-start hover:-translate-y-0.5"><span className="text-2xl">📋</span><p className="font-black mt-2">التقرير الأسبوعي</p><p className="text-[12px] text-[var(--muted)] leading-5 mt-1">تقرير لكل ابن + رسائل واتساب جاهزة للفصل كله.</p></button>
              <button onClick={() => setSection("honor")} className="card p-4 text-start hover:-translate-y-0.5"><span className="text-2xl">🏆</span><p className="font-black mt-2">لوحة الشرف</p><p className="text-[12px] text-[var(--muted)] leading-5 mt-1">{awards.length} وساماً ممنوحاً • امنح وساماً جديداً اليوم.</p></button>
              <button onClick={() => setSection("son-week")} className="card p-4 text-start hover:-translate-y-0.5"><span className="text-2xl">👑</span><p className="font-black mt-2">ابن الأسبوع</p><p className="text-[12px] text-[var(--muted)] leading-5 mt-1">ترشيح تلقائي عادل + بطاقة تهنئة جميلة.</p></button>
              <button onClick={() => setSection("alerts")} className="card p-4 text-start hover:-translate-y-0.5"><span className="text-2xl">⚠️</span><p className="font-black mt-2">تنبيه مبكر</p><p className="text-[12px] text-[var(--muted)] leading-5 mt-1">{alertStudents.length} ابناً يحتاجون انتباهك الآن.</p></button>
            </div>
            <div className="card p-4 flex flex-wrap gap-3 items-center"><Search size={18} className="text-[var(--muted)]" /><input value={search} onChange={(e) => { setSearch(e.target.value); if (e.target.value) setSection("search"); }} placeholder="ابحث فوراً بالاسم بين كل الـ 134 ابناً…" className="flex-1 min-w-[180px] bg-transparent font-bold text-[14px]" /><span className="chip bg-[var(--bg)] text-[var(--muted)]">{search ? `${filteredStudents.length} نتيجة` : "134 ابناً"}</span></div>
            <div className="card p-4 sm:p-5 flex flex-wrap items-center gap-3 border-[var(--primary)]/30 bg-white"><span className="w-11 h-11 rounded-2xl bg-[var(--primary)] text-white grid place-items-center shrink-0"><RefreshCw size={19} /></span><div className="flex-1 min-w-[180px]"><h3 className="font-black">تحديث قائمة الطلاب من مدرستي</h3><p className="text-[12.5px] text-[var(--muted)] mt-0.5">آخر تحديث: {lastSyncAt} • {roster.length} طالباً في {liveClasses.length} فصول • صدّر من مدرستي ثم ارفع الملف هنا.</p></div><button onClick={() => setSection("sync")} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5"><RefreshCw size={15} /> تحديث قائمة الطلاب من مدرستي</button></div>
            <div className="card p-4 sm:p-5 flex flex-wrap items-center gap-3 bg-[var(--primary-soft)] border-[var(--primary)]/20"><span className="w-11 h-11 rounded-2xl bg-[var(--primary)] text-white grid place-items-center shrink-0"><Phone size={19} /></span><div className="flex-1 min-w-[180px]"><h3 className="font-black">التواصل مع أولياء الأمور</h3><p className="text-[12.5px] text-[var(--muted)] mt-0.5">أرقام من ملفات الفصول — تظهر مقنّعة افتراضياً. ابحث باسم الابن أو ولي الأمر.</p></div><button onClick={() => setSection("contacts")} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">فتح قسم التواصل</button></div>
            <div className="grid sm:grid-cols-2 gap-4">{CLASSES.map((c) => <article key={c.id} className="card overflow-hidden"><div className="h-2" style={{ background: c.color }} /><div className="p-5"><div className="flex justify-between"><span className="chip" style={{ background: `${c.color}18`, color: c.color }}>{c.grade}</span><span className="text-[12px] font-bold text-[var(--muted)]">{c.students} ابناً</span></div><h3 className="text-[24px] font-black mt-3">فصل {c.name}</h3><p className="text-[13px] leading-6 mt-2 bg-[var(--bg)] rounded-xl p-3">{c.note}</p><button onClick={() => openClass(c.id)} className="mt-4 w-full bg-[var(--primary)] text-white py-3 rounded-xl font-extrabold flex items-center justify-center gap-2">افتح أبنائي في هذا الفصل <ChevronLeft size={16} /></button></div></article>)}</div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="card p-5"><h3 className="font-black mb-3">جدول اليوم</h3><div className="space-y-3">{[{ t: "08:00 — 08:45", m: "رياضيات", c: "اول/4", d: "الجمع حتى 20" }, { t: "09:00 — 09:45", m: "علوم", c: "ثالث/1", d: "أجزاء النبات" }, { t: "11:00 — 11:45", m: "لغة عربية", c: "ثالث/2", d: "القراءة الجهرية" }].map((r, i) => <div key={i} className="flex items-center gap-3 bg-[var(--bg)] rounded-2xl p-3"><span className="w-11 h-11 rounded-xl bg-white grid place-items-center shrink-0"><Clock size={19} className="text-[var(--primary)]" /></span><div className="min-w-0 flex-1"><p className="font-extrabold text-[14px] truncate">{r.m} • فصل {r.c}</p><p className="text-[12px] text-[var(--muted)]">{r.d} • {r.t}</p></div><button onClick={() => { setSelectedClass(r.c); setSection("attendance"); flash(`بدأت حصة ${r.m} — فصل ${r.c}`); }} className="shrink-0 bg-[var(--primary)] text-white px-3.5 py-2 rounded-full text-[12px] font-extrabold">ابدأ الحصة</button></div>)}</div></div>
              <div className="card p-5 bg-gradient-to-br from-violet-700 to-violet-900 !text-white border-0"><p className="text-violet-200 text-[12px] font-bold">أبنائي بانتظارك اليوم</p><h3 className="font-black text-[19px] mt-1">كل ابنٍ من أبنائك يستحق متابعة تليق به</h3><p className="text-violet-100 text-[13px] leading-6 mt-2">افتح ملف أي ابن، وسجّل حضوره ودرجاته وملاحظتك عنه — فالتفاصيل الصغيرة تصنع فرقاً كبيراً.</p><button onClick={() => setSection("classes")} className="mt-4 bg-white text-violet-800 px-4 py-2.5 rounded-full text-[13px] font-extrabold">فتح قائمة أبنائي</button></div>
            </div>
          </div>}

          {section === "search" && <div className="space-y-4 pop"><h1 className="text-[28px] font-black">نتائج البحث</h1><p className="text-[var(--muted)] text-[13px]">بحث فوري في كل الـ 134 ابناً — بالاسم أو اسم ولي الأمر أو الفصل.</p><div className="flex items-center gap-2 bg-white border border-[var(--line)] rounded-full px-4 py-2.5"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن ابني…" className="bg-transparent flex-1 min-w-0 text-sm font-bold" /></div><StudentTable students={filteredStudents} onOpen={openStudent} showClass showGuardian /></div>}

          {section === "classes" && <div className="space-y-5 pop"><div className="flex flex-wrap justify-between gap-3 items-start"><div><h1 className="text-[28px] font-black">أبنائي</h1><p className="text-[var(--muted)] text-[13px]">4 فصول • {roster.length} ابناً • اختر فصلاً لترى أبناءه الحقيقيين.</p></div><button onClick={() => setSection("sync")} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5"><RefreshCw size={15} /> تحديث قائمة الطلاب من مدرستي</button></div><p className="text-[12.5px] text-[var(--muted)] font-bold">آخر تحديث: {lastSyncAt}</p><div className="grid sm:grid-cols-2 gap-4">{CLASSES.map((c) => <article key={c.id} className="card overflow-hidden"><div className="h-2" style={{ background: c.color }} /><div className="p-5"><div className="flex justify-between"><span className="chip" style={{ background: `${c.color}18`, color: c.color }}>{c.grade}</span><span className="text-[12px] font-bold text-[var(--muted)]">{c.students} ابناً</span></div><h3 className="text-[24px] font-black mt-3">فصل {c.name}</h3><p className="text-[13px] leading-6 mt-2 bg-[var(--bg)] rounded-xl p-3">{c.note}</p><button onClick={() => openClass(c.id)} className="mt-4 w-full bg-[var(--primary)] text-white py-3 rounded-xl font-extrabold flex items-center justify-center gap-2">افتح أبنائي في هذا الفصل <ChevronLeft size={16} /></button></div></article>)}</div></div>}

          {/* ===== 1. التقرير الأسبوعي ===== */}
          {section === "weekly-report" && <div className="space-y-4 pop">
            <div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">التقرير الأسبوعي لكل طالب</h1><p className="text-[var(--muted)] text-[13px]">اختر الفصل ثم الطالب — عدّل الحضور والملاحظة، ثم أرسلها لولي الأمر.</p></div><button onClick={() => setShowBatch(!showBatch)} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">{showBatch ? "إخفاء تقرير الفصل" : "تقرير لكل الفصل"}</button></div>
            <div className="card p-4 flex flex-wrap gap-3 items-center">
              <label className="flex-1 min-w-[150px]"><span className="text-[12px] font-bold text-[var(--muted)]">الفصل</span><select value={weeklyClass} onChange={(e) => { setWeeklyClass(e.target.value); const first = ALL_STUDENTS.find(s => s.className === e.target.value); if (first) setWeeklyStudentId(first.id); }} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{CLASSES.map(c => <option key={c.id} value={c.id}>فصل {c.name} • {c.students} ابناً</option>)}</select></label>
              <label className="flex-[2] min-w-[200px]"><span className="text-[12px] font-bold text-[var(--muted)]">الطالب</span><select value={weeklyStudentId} onChange={(e) => setWeeklyStudentId(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{weeklyClassStudents.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
              <label className="flex-1 min-w-[160px]"><span className="text-[12px] font-bold text-[var(--muted)]">بحث بالاسم</span><input value={weeklySearch} onChange={(e) => setWeeklySearch(e.target.value)} placeholder="اكتب اسم الابن…" className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 text-[13px]" /></label>
            </div>
            {weeklySearch.trim() && <div className="flex flex-wrap gap-2">{weeklyFilteredForSearch.slice(0, 8).map(s => <button key={s.id} onClick={() => { setWeeklyStudentId(s.id); setWeeklySearch(""); }} className={`px-3 py-2 rounded-full text-[12px] font-extrabold border ${s.id === weeklyStudentId ? "bg-[var(--primary)] text-white" : "bg-white border-[var(--line)]"}`}>{s.name}</button>)}</div>}
            <div className="card p-5 sm:p-6">
              <div className="flex flex-wrap justify-between gap-3"><div><p className="text-[12px] font-bold text-[var(--muted)]">تقرير الأسبوع الحالي • مدرسة الربيع بن زياد الابتدائية</p><h2 className="text-[22px] font-black mt-1">{weeklyStudent.name}</h2><p className="text-[13px] text-[var(--muted)]">فصل {weeklyStudent.className} • ولي الأمر: {weeklyStudent.guardian}</p></div><span className="chip bg-[var(--primary-soft)] text-[var(--primary)] h-fit">أسبوع {new Date().toLocaleDateString("ar-SA")}</span></div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-5">
                <div className="bg-[var(--bg)] rounded-2xl p-4"><p className="text-[12px] font-bold text-[var(--muted)]">أيام الحضور</p><div className="flex items-center gap-2 mt-2"><button onClick={() => setWeeklyPresent(p => ({ ...p, [weeklyStudent.id]: Math.max(0, (p[weeklyStudent.id] ?? getPresentAbsent(weeklyStudent.id).present) - 1) }))} className="w-7 h-7 rounded-full bg-white font-black">−</button><span className="font-black text-[20px] num flex-1 text-center">{getPresentAbsent(weeklyStudent.id).present} / 5</span><button onClick={() => setWeeklyPresent(p => ({ ...p, [weeklyStudent.id]: Math.min(5, (p[weeklyStudent.id] ?? getPresentAbsent(weeklyStudent.id).present) + 1) }))} className="w-7 h-7 rounded-full bg-white font-black">+</button></div></div>
                <div className="bg-rose-50 rounded-2xl p-4"><p className="text-[12px] font-bold text-rose-600">أيام الغياب</p><div className="flex items-center gap-2 mt-2"><button onClick={() => setWeeklyAbsent(p => ({ ...p, [weeklyStudent.id]: Math.max(0, (p[weeklyStudent.id] ?? getPresentAbsent(weeklyStudent.id).absent) - 1) }))} className="w-7 h-7 rounded-full bg-white font-black">−</button><span className="font-black text-[20px] num flex-1 text-center">{getPresentAbsent(weeklyStudent.id).absent}</span><button onClick={() => setWeeklyAbsent(p => ({ ...p, [weeklyStudent.id]: Math.min(5, (p[weeklyStudent.id] ?? getPresentAbsent(weeklyStudent.id).absent) + 1) }))} className="w-7 h-7 rounded-full bg-white font-black">+</button></div></div>
                <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">الواجبات المنجزة</p><p className="font-black text-[20px] num mt-2">{grades[weeklyStudent.id]?.h || 0} / 10</p></div>
                <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">المشاركة • السلوك</p><p className="font-black text-[20px] num mt-2">{grades[weeklyStudent.id]?.p || 0} • {grades[weeklyStudent.id]?.b || 0} / 10</p></div>
              </div>
              {growthNotes[weeklyStudent.id] && <div className="mt-4 bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-2"><TrendingUp size={18} className="text-amber-600 shrink-0 mt-0.5" /><p className="text-[13px] leading-6"><b>سجل النمو:</b> {growthNotes[weeklyStudent.id]}</p></div>}
              <label className="block mt-4"><span className="text-[12px] font-bold text-[var(--muted)]">ملاحظة المعلم — قابلة للتحرير</span><textarea value={notes[weeklyStudent.id] || ""} onChange={(e) => setNotes(p => ({ ...p, [weeklyStudent.id]: e.target.value }))} rows={3} placeholder="اكتب ملاحظتك عن ابنك هذا الأسبوع…" className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-2xl px-3 py-3 text-[13.5px] leading-6" /></label>
              <div className="flex flex-wrap gap-2 mt-3">
                <button onClick={() => saveNoteFor(weeklyStudent.id)} disabled={busy} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold disabled:opacity-60">حفظ الملاحظة</button>
                <button onClick={() => setShowWeeklyMsg(!showWeeklyMsg)} className="bg-[var(--green)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5"><MessageCircle size={16} /> توليد رسالة واتساب</button>
                <button onClick={() => openStudent(weeklyStudent)} className="px-4 py-2.5 rounded-full border border-[var(--line)] text-[13px] font-extrabold">فتح ملف الابن + خطته</button>
              </div>
              {showWeeklyMsg && <div className="mt-4 border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)]"><p className="text-[12px] font-bold text-[var(--muted)]">نص جاهز لولي الأمر — {weeklyStudent.guardian}</p><p className="whitespace-pre-line text-[13.5px] leading-7 bg-white rounded-xl p-3 mt-2 border border-[var(--line)]">{weeklyMessageFor(weeklyStudent)}</p><div className="flex flex-wrap gap-2 mt-3"><button onClick={() => copyText(weeklyMessageFor(weeklyStudent), "تم نسخ رسالة التقرير")} className="px-4 py-2.5 rounded-full bg-white border border-[var(--line)] text-[13px] font-extrabold flex items-center gap-1.5"><Copy size={15} /> نسخ النص</button>{excelPhones[weeklyStudent.id] ? <a href={waLink(excelPhones[weeklyStudent.id], weeklyMessageFor(weeklyStudent))} target="_blank" rel="noopener" className="px-4 py-2.5 rounded-full bg-[var(--green)] text-white text-[13px] font-extrabold flex items-center gap-1.5"><MessageCircle size={15} /> فتح واتساب على رقم ولي الأمر</a> : <span className="text-[12px] text-[var(--muted)] font-bold py-2">لا يوجد رقم مسجّل لهذا الابن في ملفات الفصول.</span>}</div></div>}
            </div>
            {showBatch && <div className="card p-5">
              <h3 className="font-black">تقرير لكل الفصل — فصل {weeklyClass}</h3><p className="text-[12.5px] text-[var(--muted)] mt-1">جهّز رسائل كل الطلاب دفعة واحدة — ابحث بالاسم ثم انسخ أو افتح واتساب لكل ابن.</p>
              <div className="flex items-center gap-2 bg-[var(--bg)] border border-[var(--line)] rounded-full px-4 py-2.5 mt-4"><Search size={17} /><input value={batchSearch} onChange={(e) => setBatchSearch(e.target.value)} placeholder="بحث بالاسم في تقرير الفصل…" className="bg-transparent flex-1 min-w-0 text-sm font-bold" /><span className="chip bg-white">{batchFiltered.length} ابناً</span></div>
              <div className="grid sm:grid-cols-2 gap-3 mt-4">{batchFiltered.map(s => { const msg = weeklyMessageFor(s); const phone = excelPhones[s.id]; return <article key={s.id} className="border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)]"><div className="flex justify-between gap-2"><b className="leading-6">{s.name}</b><span className="text-[11px] text-[var(--muted)] shrink-0">حضور {getPresentAbsent(s.id).present}/5 • مجموع {(grades[s.id]?.h || 0) + (grades[s.id]?.p || 0) + (grades[s.id]?.b || 0)}/30</span></div><p className="text-[12.5px] text-[var(--muted)] leading-6 mt-2 line-clamp-3">{msg}</p><div className="flex flex-wrap gap-2 mt-3"><button onClick={() => copyText(msg, "تم نسخ تقرير الابن")} className="px-3 py-2 rounded-full bg-white border border-[var(--line)] text-[12px] font-extrabold flex items-center gap-1"><Copy size={13} /> نسخ</button>{phone ? <a href={waLink(phone, msg)} target="_blank" rel="noopener" className="px-3 py-2 rounded-full bg-[var(--green)] text-white text-[12px] font-extrabold flex items-center gap-1"><MessageCircle size={13} /> واتساب</a> : <span className="text-[11px] text-[var(--muted)] font-bold py-2">بدون رقم مسجّل</span>}<button onClick={() => { setWeeklyStudentId(s.id); setShowBatch(false); window.scrollTo({ top: 0 }); }} className="px-3 py-2 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] text-[12px] font-extrabold">فتح تقريره</button></div></article>; })}</div>
            </div>}
          </div>}

          {/* ===== 3. لوحة الشرف ===== */}
          {section === "honor" && <div className="space-y-4 pop">
            <div className="relative overflow-hidden rounded-[26px] border border-amber-200 bg-gradient-to-l from-amber-50 via-white to-violet-50 p-5 sm:p-6">
              <div className="flex flex-wrap justify-between gap-3 items-center"><div><p className="text-[13px] font-bold text-amber-700">✨ نجوم الأسبوع ✨</p><h1 className="text-[28px] font-black mt-1">لوحة الشرف الرقمية</h1><p className="text-[13px] text-[var(--muted)] mt-1">نحتفي بأبنائنا — كل وسام حكاية اجتهاد تستحق التصفيق.</p></div><div className="flex gap-2"><span className="chip bg-white shadow">🏆 {awards.length} وساماً</span><span className="chip bg-white shadow">⭐ {Object.keys(honorCounts).length} ابناً مكرّماً</span></div></div>
              <div className="flex gap-1 mt-4 text-2xl"><span className="floaty">⭐</span><span className="floaty" style={{ animationDelay: ".4s" }}>🌟</span><span className="floaty" style={{ animationDelay: ".8s" }}>🎉</span><span className="floaty" style={{ animationDelay: "1.2s" }}>🏅</span></div>
            </div>
            <div className="card p-5">
              <h3 className="font-black flex items-center gap-2"><Gift size={18} className="text-[var(--primary)]" /> امنح وساماً جديداً</h3>
              <div className="grid sm:grid-cols-3 gap-3 mt-3">
                <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">الطالب</span><select value={honorStudentId} onChange={(e) => setHonorStudentId(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{ALL_STUDENTS.map(s => <option key={s.id} value={s.id}>{s.name} • فصل {s.className}</option>)}</select></label>
                <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">الوسام</span><select value={honorMedalPick} onChange={(e) => setHonorMedalPick(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{MEDALS.map(m => <option key={m.id} value={m.id}>{m.emoji} {m.label}</option>)}</select></label>
                <div className="flex items-end"><button onClick={awardMedal} disabled={busy} className="w-full bg-amber-500 text-white py-3 rounded-xl font-extrabold disabled:opacity-60 flex items-center justify-center gap-2"><Trophy size={17} /> {busy ? "جارٍ الحفظ…" : "امنح الوسام"}</button></div>
              </div>
              <div className="flex flex-wrap gap-2 mt-3">{MEDALS.map(m => <button key={m.id} onClick={() => setHonorMedalPick(m.id)} className={`px-3 py-2 rounded-full text-[12px] font-extrabold border ${honorMedalPick === m.id ? "text-white" : ""}`} style={honorMedalPick === m.id ? { background: m.color } : { background: m.bg, color: m.color }}>{m.emoji} {m.label}</button>)}</div>
            </div>
            <div className="card p-4 flex flex-wrap gap-3 items-center">
              <label className="flex-1 min-w-[140px]"><span className="text-[12px] font-bold text-[var(--muted)]">الفصل</span><select value={honorClass} onChange={(e) => setHonorClass(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>الكل</option>{CLASSES.map(c => <option key={c.id} value={c.id}>فصل {c.name}</option>)}</select></label>
              <label className="flex-1 min-w-[140px]"><span className="text-[12px] font-bold text-[var(--muted)]">الوسام</span><select value={honorMedal} onChange={(e) => setHonorMedal(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>الكل</option>{MEDALS.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}</select></label>
              <span className="chip bg-[var(--bg)]">{honorFiltered.length} وساماً مطابقاً</span>
            </div>
            {topHonor.length > 0 && <div className="card p-5"><h3 className="font-black mb-3">🏅 أكثر الأبناء أوسمة</h3><div className="flex flex-wrap gap-3">{topHonor.map(({ student, count }) => student && <button key={student.id} onClick={() => openStudent(student)} className="flex items-center gap-2 bg-[var(--bg)] rounded-full ps-2 pe-4 py-2 font-extrabold text-[13px]"><span className="w-8 h-8 rounded-full bg-[var(--primary-soft)] grid place-items-center">{student.name[0]}</span>{student.name}<span className="chip bg-amber-100 text-amber-700">{count} أوسمة</span></button>)}</div></div>}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {honorFiltered.map(a => { const m = MEDALS.find(x => x.id === a.medal)!; return <article key={a.id} className="card p-5 text-center" style={{ borderTop: `4px solid ${m.color}` }}><p className="text-[38px] leading-none">{m.emoji}</p><p className="chip mt-3 inline-block" style={{ background: m.bg, color: m.color }}>{m.label}</p><h3 className="font-black text-[17px] mt-2 leading-7">{a.studentName}</h3><p className="text-[12px] text-[var(--muted)]">فصل {a.className} • {a.date}</p><p className="text-[12px] font-bold text-[var(--muted)] mt-2">عدد أوسمته: {honorCounts[a.studentId] || 1}</p><button onClick={() => { const s = ALL_STUDENTS.find(x => x.id === a.studentId); if (s) openStudent(s); }} className="mt-3 px-4 py-2 rounded-full bg-[var(--bg)] border border-[var(--line)] text-[12px] font-extrabold">فتح ملف الابن</button></article>; })}
            </div>
            {honorFiltered.length === 0 && <div className="card p-8 text-center"><p className="text-4xl">🌟</p><p className="font-black mt-3">لا توجد أوسمة بعد بهذا الفلتر</p><p className="text-[13px] text-[var(--muted)] mt-1">امنح أول وسام من الأعلى — وسيظهر هنا فوراً.</p></div>}
          </div>}

          {/* ===== 4. ابن الأسبوع ===== */}
          {section === "son-week" && <div className="space-y-4 pop">
            <div><h1 className="text-[28px] font-black">ابن الأسبوع 👑</h1><p className="text-[var(--muted)] text-[13px]">ترشيح تلقائي عادل: حضور كامل + واجبات كاملة + مشاركة ممتازة + سلوك رائع — مع إمكانية اختيار يدوي.</p></div>
            <div className="card p-4 flex flex-wrap gap-3 items-center">
              <label className="flex-1 min-w-[150px]"><span className="text-[12px] font-bold text-[var(--muted)]">الفصل</span><select value={sonClass} onChange={(e) => { setSonClass(e.target.value); setSonCandidateId(""); }} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{CLASSES.map(c => <option key={c.id} value={c.id}>فصل {c.name} • {c.students} ابناً</option>)}</select></label>
              <label className="flex-[2] min-w-[200px]"><span className="text-[12px] font-bold text-[var(--muted)]">اختيار يدوي (اختياري — يقدَّم على الترشيح التلقائي)</span><select value={sonCandidateId} onChange={(e) => setSonCandidateId(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option value="">— ترشيح تلقائي —</option>{sonClassStudents.map(s => <option key={s.id} value={s.id}>{s.name} • نقاطه {evalScore(s.id)}/12</option>)}</select></label>
            </div>
            {/* Evaluation buttons */}
            <div className="card p-5">
              <h3 className="font-black flex items-center gap-2"><Star size={18} className="text-amber-500" /> قيّم أبناء فصل {sonClass} — الترشيح يتحدّث مع تقييمك</h3>
              <p className="text-[12.5px] text-[var(--muted)] mt-1">اضغط على كل معيار لكل ابن: ممتاز / جيد / يحتاج دعم. الترشيح التلقائي يختار الأعلى نقاطاً.</p>
              <div className="grid md:grid-cols-2 gap-3 mt-4 max-h-[420px] overflow-y-auto ps-1">
                {sonClassStudents.map(s => {
                  const e = evaluations[s.id] || { att: "ممتاز", hw: "ممتاز", part: "ممتاز", beh: "ممتاز" };
                  const isAuto = autoSon?.id === s.id && !sonCandidateId;
                  return <div key={s.id} className={`border rounded-2xl p-3 ${isAuto ? "border-amber-400 bg-amber-50" : "border-[var(--line)] bg-[var(--bg)]"}`}><div className="flex justify-between gap-2"><b className="text-[13.5px] leading-6">{s.name} {isAuto && <span className="chip bg-amber-100 text-amber-700">مرشح تلقائي</span>}</b><span className="chip bg-white shrink-0">{evalScore(s.id)}/12</span></div>
                    <div className="grid grid-cols-2 gap-2 mt-2">{([["att", "الحضور"], ["hw", "الواجبات"], ["part", "المشاركة"], ["beh", "السلوك"]] as const).map(([key, label]) => <label key={key} className="block"><span className="text-[11px] font-bold text-[var(--muted)]">{label}</span><select value={e[key]} onChange={(ev) => setEvaluations(p => ({ ...p, [s.id]: { ...e, [key]: ev.target.value } }))} className="w-full mt-0.5 bg-white border border-[var(--line)] rounded-lg px-2 py-1.5 text-[12px] font-bold"><option>ممتاز</option><option>جيد</option><option>يحتاج دعم</option></select></label>)}</div></div>;
                })}
              </div>
            </div>
            {/* Congratulation card */}
            {sonCandidate && <div className="relative overflow-hidden rounded-[26px] border border-amber-200 shadow-[var(--shadow)]">
              <img src={schoolImageUrl} alt="مبنى مدرسة الربيع بن زياد الابتدائية" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-l from-white via-white/92 to-white/40" aria-hidden="true" />
              <div className="relative p-5 sm:p-8 text-center">
                <p className="text-4xl">👑</p><p className="text-[13px] font-bold text-amber-700 mt-2">مدرسة الربيع بن زياد الابتدائية • فصل {sonCandidate.className}</p>
                <h2 className="text-[clamp(26px,5vw,40px)] font-black mt-2 leading-tight">فخورون بك يا بطل، أنت ابن الأسبوع</h2>
                <p className="text-[20px] font-black text-[var(--primary)] mt-2">{sonCandidate.name}</p>
                <p className="text-[13.5px] text-[var(--muted)] leading-6 mt-2 max-w-[560px] mx-auto">لحضوره الكامل واجتهاده ومشاركته الرائعة وأخلاقه الجميلة — واصل تألقك فأنت قدوة لزملائك.</p>
                <p className="font-black mt-4">— أ. عبدالعزيز —</p>
                <div className="flex flex-wrap justify-center gap-2 mt-5">
                  <button onClick={() => saveSonOfWeek(sonCandidate, `حضور كامل + واجبات كاملة + مشاركة ممتازة + سلوك رائع — نقاطه ${evalScore(sonCandidate.id)}/12`)} disabled={busy} className="bg-[var(--primary)] text-white px-5 py-3 rounded-full text-[13px] font-extrabold disabled:opacity-60 flex items-center gap-1.5"><Crown size={16} /> اعتماد {sonCandidate.name} ابن الأسبوع</button>
                  <button onClick={() => copyText(congratsMessageFor(sonCandidate), "تم نسخ نص التهنئة")} className="px-5 py-3 rounded-full bg-white border border-[var(--line)] text-[13px] font-extrabold flex items-center gap-1.5"><Copy size={15} /> نسخ نص التهنئة</button>
                  {excelPhones[sonCandidate.id] ? <a href={waLink(excelPhones[sonCandidate.id], congratsMessageFor(sonCandidate))} target="_blank" rel="noopener" className="px-5 py-3 rounded-full bg-[var(--green)] text-white text-[13px] font-extrabold flex items-center gap-1.5"><MessageCircle size={15} /> إرسال لولي الأمر عبر واتساب</a> : <span className="text-[12px] font-bold text-[var(--muted)] py-3">لا يوجد رقم مسجّل لهذا الابن.</span>}
                </div>
              </div>
            </div>}
            <div className="card p-5"><h3 className="font-black flex items-center gap-2"><CalendarCheck size={18} className="text-[var(--primary)]" /> سجل أبناء الأسابيع السابقة</h3>{sonHistory.length === 0 ? <p className="text-[13px] text-[var(--muted)] mt-2">لا يوجد سجل بعد — اعتمد أول ابن أسبوع من البطاقة أعلاه وسيظهر هنا.</p> : <div className="grid sm:grid-cols-2 gap-3 mt-3">{sonHistory.map(h => <div key={h.id} className="flex items-center gap-3 bg-[var(--bg)] rounded-2xl p-3"><span className="text-2xl">👑</span><div className="flex-1 min-w-0"><b className="block truncate">{h.studentName}</b><p className="text-[12px] text-[var(--muted)]">فصل {h.className} • {h.date}</p><p className="text-[12px] text-[var(--muted)] leading-5">{h.reason}</p></div><button onClick={() => { const s = ALL_STUDENTS.find(x => x.id === h.studentId); if (s) openStudent(s); }} className="shrink-0 px-3 py-2 rounded-full bg-white border border-[var(--line)] text-[12px] font-extrabold">ملفه</button></div>)}</div>}</div>
          </div>}

          {/* ===== تنبيه مبكر ===== */}
          {section === "alerts" && <div className="space-y-4 pop">
            <div><h1 className="text-[28px] font-black">تنبيه مبكر ⚠️</h1><p className="text-[var(--muted)] text-[13px]">قائمة تلقائية «انتبه لهؤلاء الأبناء» — غاب 3 مرات أو أكثر، أو تراجعت مشاركته، أو تراجعت واجباته.</p></div>
            <div className="card p-4 flex flex-wrap gap-3 items-center bg-amber-50 border-amber-200"><AlertTriangle size={20} className="text-amber-600" /><p className="font-extrabold text-[14px] flex-1 min-w-[180px]">لديك {alertStudents.length} ابناً يحتاجون انتباهك — تواصل مبكر اليوم يمنع تراجعاً أكبر غداً.</p><button onClick={() => setSection("attendance")} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">فتح الحضور</button></div>
            <div className="card p-4 flex items-center gap-2"><Search size={18} className="text-[var(--muted)]" /><input value={alertSearch} onChange={(e) => setAlertSearch(e.target.value)} placeholder="بحث باسم الابن أو ولي الأمر…" className="flex-1 min-w-0 bg-transparent font-bold text-[14px]" /><span className="chip bg-[var(--bg)]">{alertFiltered.length} ابناً</span></div>
            <div className="grid sm:grid-cols-2 gap-3">{alertFiltered.map(({ s, reasons }) => { const quick = `السلام عليكم ورحمة الله،\nأتواصل معكم بخصوص ابنكم ${s.name} من فصل ${s.className} للاطمئنان عليه وتبادل الملاحظات بما يخدم مصلحته.\nلاحظت: ${reasons.join("، ")}.\nيسعدني تواصلكم مع المدرسة، وسنتابع معه معاً بإذن الله.\nمع خالص التقدير، أ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية`; const phone = excelPhones[s.id]; return <article key={s.id} className="card p-4"><div className="flex justify-between gap-2"><div><b className="leading-6">{s.name}</b><p className="text-[12px] text-[var(--muted)]">فصل {s.className} • ولي الأمر: {s.guardian}</p></div><span className="chip bg-rose-50 text-rose-600 shrink-0">يحتاج انتباهاً</span></div><ul className="mt-3 space-y-1">{reasons.map((r, i) => <li key={i} className="text-[13px] leading-6 flex gap-2"><span>•</span><span>{r}</span></li>)}</ul><div className="flex flex-wrap gap-2 mt-3"><button onClick={() => copyText(quick, "تم نسخ رسالة المتابعة")} className="px-3 py-2 rounded-full bg-white border border-[var(--line)] text-[12px] font-extrabold flex items-center gap-1"><Copy size={13} /> نسخ رسالة سريعة</button>{phone ? <a href={waLink(phone, quick)} target="_blank" rel="noopener" className="px-3 py-2 rounded-full bg-[var(--green)] text-white text-[12px] font-extrabold flex items-center gap-1"><MessageCircle size={13} /> رسالة سريعة لولي الأمر</a> : <span className="text-[11px] text-[var(--muted)] font-bold py-2">بدون رقم مسجّل</span>}<button onClick={() => openStudent(s)} className="px-3 py-2 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] text-[12px] font-extrabold">فتح ملفه + خطته</button></div></article>; })}</div>
            {alertFiltered.length === 0 && <div className="card p-8 text-center"><p className="text-4xl">💚</p><p className="font-black mt-3">لا توجد تنبيهات مطابقة</p><p className="text-[13px] text-[var(--muted)] mt-1">كل الأبناء بخير حسب المعايير الحالية.</p></div>}
          </div>}

          {/* ===== القرعة العادلة ===== */}
          {section === "draw" && <div className="space-y-4 pop">
            <div><h1 className="text-[28px] font-black">القرعة العادلة 🎲</h1><p className="text-[var(--muted)] text-[13px]">من يشارك الآن؟ — اختيار عشوائي بدون تكرار حتى يشارك الجميع.</p></div>
            <div className="card p-4 flex flex-wrap gap-3 items-center">
              <label className="flex-1 min-w-[160px]"><span className="text-[12px] font-bold text-[var(--muted)]">الفصل</span><select value={drawClass} onChange={(e) => { setDrawClass(e.target.value); setDrawPool([]); setDrawHistory([]); setCurrentDraw(null); }} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{CLASSES.map(c => <option key={c.id} value={c.id}>فصل {c.name} • {c.students} ابناً</option>)}</select></label>
              <span className="chip bg-[var(--bg)]">بقي في الجولة: {drawPool.length || drawClassStudents.length} ابناً • شارك: {drawHistory.length}</span>
            </div>
            <div className="card p-6 sm:p-8 text-center">
              <p className="text-5xl">{drawSpinning ? "🎲" : "🙋"}</p>
              {currentDraw ? <><p className="text-[13px] text-[var(--muted)] font-bold mt-3">دور المشاركة الآن لـ</p><h2 className="text-[clamp(24px,5vw,34px)] font-black mt-1">{currentDraw.name}</h2><p className="text-[13px] text-[var(--muted)]">فصل {currentDraw.className} • ولي الأمر: {currentDraw.guardian}</p></> : <><h2 className="text-[22px] font-black mt-3">جاهزون؟</h2><p className="text-[13px] text-[var(--muted)] mt-1">اضغط الزر وسيختار التطبيق ابناً عشوائياً من فصل {drawClass}.</p></>}
              <div className="flex flex-wrap justify-center gap-2 mt-5">
                <button onClick={doDraw} disabled={drawSpinning} className="bg-[var(--primary)] text-white px-6 py-3.5 rounded-full font-extrabold disabled:opacity-60 flex items-center gap-2"><Shuffle size={18} /> {drawSpinning ? "جارٍ الاختيار…" : "من يشارك الآن؟"}</button>
                <button onClick={() => { setDrawPool([]); setDrawHistory([]); setCurrentDraw(null); flash("بدأت جولة قرعة جديدة"); }} className="px-5 py-3.5 rounded-full border border-[var(--line)] font-extrabold flex items-center gap-1.5"><RotateCcw size={16} /> جولة جديدة</button>
                {currentDraw && <button onClick={() => openStudent(currentDraw)} className="px-5 py-3.5 rounded-full bg-[var(--green)] text-white font-extrabold">فتح ملف الابن</button>}
              </div>
              <p className="text-[12px] text-[var(--muted)] mt-3">بدون تكرار: لا يتكرر الابن حتى يشارك كل أبناء الفصل مرة واحدة.</p>
            </div>
            {drawHistory.length > 0 && <div className="card p-5"><h3 className="font-black mb-3">شاركوا في هذه الجولة</h3><div className="flex flex-wrap gap-2">{drawHistory.map((s, i) => <span key={`${s.id}-${i}`} className="chip bg-[var(--bg)]">{i + 1}. {s.name}</span>)}</div></div>}
          </div>}

          {section === "sync" && <div className="space-y-4 pop">
            <div className="flex flex-wrap justify-between gap-3 items-start"><div><h1 className="text-[28px] font-black">تحديث مدرستي — تحديث قائمة الطلاب من مدرستي</h1><p className="text-[var(--muted)] text-[13px]">آخر تحديث: {lastSyncAt} • {roster.length} طالباً حالياً • {archived.length} مؤرشفاً</p><p className="text-[13.5px] font-bold leading-6 mt-2">ادخل مدرستي من المتصفح وصدّر قائمة الطلاب Excel ثم ارفع الملف هنا — وراجع المعاينة قبل الحفظ.</p></div><a href={MADRASATI_URL} target="_blank" rel="noopener" className="bg-[var(--green)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5"><ExternalLink size={15} /> فتح منصة مدرستي</a></div>
            <div className="card p-4 sm:p-5 bg-amber-50 border-amber-200 flex gap-3"><Info size={20} className="text-amber-600 shrink-0 mt-0.5" /><div><p className="font-black text-[14px]">الربط المباشر التلقائي مع منصة مدرستي غير متاح لأن المنصة لا توفر واجهة رسمية للمعلم</p><p className="text-[13px] leading-6 mt-1 text-[var(--muted)]">لذلك التحديث يكون عبر تصدير قائمة الطلاب من مدرستي ثم رفعها هنا — آمن ورسمي. الدرجات تبقى في منصة مدرستي والتطبيق يركز على المتابعة والتواصل والتقارير.</p></div></div>
            <div className="card p-5"><h3 className="font-black">خطوات التصدير من مدرستي</h3><ol className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">{[["1", "ادخل على مدرستي من المتصفح", "افتح منصة مدرستي بحسابك الرسمي."], ["2", "افتح قائمة الطلاب / فصولي", "اختر الفصول التي تدرّسها."], ["3", "اضغط تصدير Excel", "حمّل قائمة الطلاب بصيغة Excel أو CSV."], ["4", "ارفع الملف هنا", "اسحب الملف أدناه أو اختره من جهازك."]].map(([n, t, d]) => <li key={n} className="bg-[var(--bg)] rounded-2xl p-4"><span className="w-8 h-8 rounded-full bg-[var(--primary)] text-white grid place-items-center font-black text-[14px]">{n}</span><p className="font-black mt-2 text-[13.5px] leading-6">{t}</p><p className="text-[12px] text-[var(--muted)] leading-5 mt-1">{d}</p></li>)}</ol><div className="flex flex-wrap gap-2 mt-4"><a href={MADRASATI_URL} target="_blank" rel="noopener" className="px-4 py-2.5 rounded-full bg-[var(--green)] text-white text-[13px] font-extrabold flex items-center gap-1.5"><ExternalLink size={15} /> فتح منصة مدرستي للتصدير</a><button onClick={demoPreview} className="px-4 py-2.5 rounded-full border border-[var(--line)] text-[13px] font-extrabold">جرّب معاينة تجريبية</button></div></div>
            <div className="grid sm:grid-cols-4 gap-3">{liveClasses.map((c) => <div key={c.id} className="card p-4 text-center"><p className="font-black text-[22px] num">{c.students}</p><p className="text-[12px] font-bold text-[var(--muted)]">فصل {c.name} • {c.grade}</p></div>)}</div>
            <div className="card p-5">
              <h3 className="font-black flex items-center gap-2"><FileSpreadsheet size={18} className="text-[var(--primary)]" /> منطقة رفع ملف Excel / CSV</h3>
              <p className="text-[12.5px] text-[var(--muted)] mt-1">يقبل ملفات مدرستي ونور (أعمدة: اسم الطالب والفصل ورقم الطالب إن وجد).</p>
              <div onDragOver={(e) => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={(e) => { e.preventDefault(); setDragOver(false); handleRosterFile(e.dataTransfer.files?.[0]); }} className={`mt-4 border-2 border-dashed rounded-[22px] p-6 sm:p-8 text-center ${dragOver ? "border-[var(--primary)] bg-[var(--primary-soft)]" : "border-[var(--line)] bg-[var(--bg)]"}`}>
                <span className="text-4xl">📁</span><p className="font-black mt-2">اسحب الملف هنا أو اختره</p><p className="text-[12.5px] text-[var(--muted)] mt-1">Excel (.xlsx) أو CSV • لن يُحفظ شيء قبل أن تراجع المعاينة وتضغط تأكيد التحديث</p>
                <label className="inline-flex items-center gap-2 mt-4 bg-[var(--primary)] text-white px-5 py-3 rounded-full text-[13px] font-extrabold cursor-pointer"><Upload size={16} /> اختر ملفاً من جهازك<input type="file" accept=".xlsx,.xls,.csv,.txt" className="hidden" onChange={(e) => { handleRosterFile(e.target.files?.[0]); e.target.value = ""; }} /></label>
                {syncFileName && <p className="text-[12.5px] font-bold mt-3">الملف المختار: {syncFileName} • {syncIncoming.length} طالباً في الملف</p>}
                {syncParsing && <p className="text-[13px] font-bold text-[var(--primary)] mt-2">جارٍ قراءة الملف ومطابقة الأسماء…</p>}
              </div>
              {syncError && <p className="mt-3 bg-rose-50 text-rose-700 rounded-2xl p-3 text-[13px] font-bold">{syncError}</p>}
              {syncResult && <div className="mt-3 bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-[13px] leading-6"><p className="font-black">نتيجة الحفظ: تم حفظ {syncResult.saved} • المتبقي {syncResult.remaining}</p>{syncResult.error && <p className="text-rose-700 font-bold mt-1">خطأ: {syncResult.error}</p>}{syncResult.reloadError && <p className="text-amber-700 font-bold mt-1">تعذّرت إعادة التحميل: {syncResult.reloadError}</p>}{!syncResult.error && <p className="font-black text-emerald-700 mt-1">تم تحديث القائمة: +{syncResult.saved} — راجع أعداد الفصول أعلاه.</p>}</div>}
            </div>
            {syncPreview && <div className="space-y-4">
              <div className="card p-5"><h3 className="font-black">معاينة قبل الحفظ — راجع ثم أكّد</h3><p className="text-[12.5px] text-[var(--muted)] mt-1">طلاب بدون تغيير: <b>{syncPreview.unchanged}</b> طالباً • ألغِ تحديد أي صف لا تريد تطبيقه قبل التأكيد.</p><div className="flex flex-wrap gap-2 mt-4"><button onClick={confirmSync} disabled={syncConfirming || busy} className="bg-[var(--green)] text-white px-5 py-3 rounded-full text-[13px] font-extrabold disabled:opacity-60 flex items-center gap-1.5"><Check size={16} /> {syncConfirming ? "جارٍ الحفظ في قاعدة البيانات…" : "تأكيد التحديث"}</button><button onClick={() => { setSyncPreview(null); setSyncIncoming([]); }} className="px-5 py-3 rounded-full border border-[var(--line)] text-[13px] font-extrabold">إلغاء المعاينة</button></div></div>
              <div className="card p-5 border-emerald-200"><h4 className="font-black text-emerald-700 flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-emerald-500 text-white grid place-items-center text-[12px]">✓</span> طلاب جدد ({syncPreview.added.length})</h4>{syncPreview.added.length === 0 ? <p className="text-[13px] text-[var(--muted)] mt-2">لا يوجد طلاب جدد في هذا الملف.</p> : <div className="overflow-x-auto mt-3"><table className="w-full text-[13px] min-w-[480px]"><thead className="bg-emerald-50"><tr><th className="p-3 text-start">إضافة</th><th className="p-3 text-start">الاسم</th><th className="p-3 text-start">الفصل الجديد</th><th className="p-3 text-start">الإجراء</th></tr></thead><tbody>{syncPreview.added.map((r) => <tr key={normName(r.name)} className="border-t border-[var(--line)]"><td className="p-3"><input type="checkbox" checked={!!selectedAdded[normName(r.name)]} onChange={(e) => setSelectedAdded((p) => ({ ...p, [normName(r.name)]: e.target.checked }))} aria-label={`إضافة ${r.name}`} /></td><td className="p-3 font-bold">{r.name}</td><td className="p-3">فصل {r.className}</td><td className="p-3"><button onClick={() => setSelectedAdded((p) => ({ ...p, [normName(r.name)]: true }))} className="px-3 py-1.5 rounded-full bg-emerald-500 text-white text-[12px] font-extrabold">إضافة</button></td></tr>)}</tbody></table></div>}</div>
              <div className="card p-5 border-amber-200"><h4 className="font-black text-amber-700 flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-amber-500 text-white grid place-items-center text-[12px]">⇄</span> طلاب منقولون ({syncPreview.moved.length})</h4><p className="text-[12.5px] text-[var(--muted)] mt-1">النقل يحتفظ بسجل متابعته وخططه وملاحظاته السابقة.</p>{syncPreview.moved.length === 0 ? <p className="text-[13px] text-[var(--muted)] mt-2">لا يوجد طلاب منقولون في هذا الملف.</p> : <div className="overflow-x-auto mt-3"><table className="w-full text-[13px] min-w-[520px]"><thead className="bg-amber-50"><tr><th className="p-3 text-start">نقل</th><th className="p-3 text-start">الاسم</th><th className="p-3 text-start">من فصل</th><th className="p-3 text-start">إلى فصل</th><th className="p-3 text-start">الإجراء</th></tr></thead><tbody>{syncPreview.moved.map((m) => <tr key={m.student.id} className="border-t border-[var(--line)]"><td className="p-3"><input type="checkbox" checked={!!selectedMoved[m.student.id]} onChange={(e) => setSelectedMoved((p) => ({ ...p, [m.student.id]: e.target.checked }))} aria-label={`نقل ${m.student.name}`} /></td><td className="p-3 font-bold">{m.student.name}</td><td className="p-3">فصل {m.from}</td><td className="p-3">فصل {m.to}</td><td className="p-3"><button onClick={() => setSelectedMoved((p) => ({ ...p, [m.student.id]: true }))} className="px-3 py-1.5 rounded-full bg-amber-500 text-white text-[12px] font-extrabold">نقل مع الاحتفاظ بسجله</button></td></tr>)}</tbody></table></div>}</div>
              <div className="card p-5 border-[var(--line)]"><h4 className="font-black text-[var(--muted)] flex items-center gap-2"><span className="w-6 h-6 rounded-full bg-slate-400 text-white grid place-items-center text-[12px]">◌</span> طلاب غير موجودين في الملف الجديد ({syncPreview.missing.length})</h4><p className="text-[12.5px] text-[var(--muted)] mt-1">الأرشفة لا تحذف نهائياً — ينقل الطالب لقائمة المؤرشفين مع سجله.</p>{syncPreview.missing.length === 0 ? <p className="text-[13px] text-[var(--muted)] mt-2">كل الطلاب الحاليين موجودون في الملف الجديد.</p> : <div className="overflow-x-auto mt-3"><table className="w-full text-[13px] min-w-[520px]"><thead className="bg-[var(--bg)]"><tr><th className="p-3 text-start">أرشفة</th><th className="p-3 text-start">الاسم</th><th className="p-3 text-start">الفصل القديم</th><th className="p-3 text-start">الإجراء</th></tr></thead><tbody>{syncPreview.missing.map((s) => <tr key={s.id} className="border-t border-[var(--line)]"><td className="p-3"><input type="checkbox" checked={!!selectedMissing[s.id]} onChange={(e) => setSelectedMissing((p) => ({ ...p, [s.id]: e.target.checked }))} aria-label={`أرشفة ${s.name}`} /></td><td className="p-3 font-bold">{s.name}</td><td className="p-3">فصل {s.className}</td><td className="p-3"><button onClick={() => setSelectedMissing((p) => ({ ...p, [s.id]: true }))} className="px-3 py-1.5 rounded-full bg-slate-500 text-white text-[12px] font-extrabold">أرشفة</button></td></tr>)}</tbody></table></div>}</div>
            </div>}
            <div className="card p-5"><div className="flex flex-wrap justify-between gap-3 items-center"><div><h3 className="font-black flex items-center gap-2"><Archive size={18} className="text-[var(--primary)]" /> الطلاب المؤرشفون ({archived.length})</h3><p className="text-[12.5px] text-[var(--muted)] mt-1">قائمة من تم نقلهم خارج فصولي — يمكن استرجاعهم إذا عادوا.</p></div><button onClick={() => setShowArchived(!showArchived)} className="px-4 py-2.5 rounded-full border border-[var(--line)] text-[13px] font-extrabold">{showArchived ? "إخفاء المؤرشفين" : "عرض المؤرشفين"}</button></div>{showArchived && <div className="mt-4"><div className="flex items-center gap-2 bg-[var(--bg)] border border-[var(--line)] rounded-full px-4 py-2.5"><Search size={16} className="text-[var(--muted)]" /><input value={archivedSearch} onChange={(e) => setArchivedSearch(e.target.value)} placeholder="ابحث في المؤرشفين بالاسم…" className="bg-transparent flex-1 min-w-0 text-[13px] font-bold" /></div>{archived.filter((s) => !archivedSearch.trim() || s.name.includes(archivedSearch.trim()) || s.guardian.includes(archivedSearch.trim())).length === 0 ? <p className="text-center text-[13px] text-[var(--muted)] font-bold py-6">لا يوجد طلاب مؤرشفون بعد.</p> : <div className="grid sm:grid-cols-2 gap-3 mt-3">{archived.filter((s) => !archivedSearch.trim() || s.name.includes(archivedSearch.trim()) || s.guardian.includes(archivedSearch.trim())).map((s) => <article key={s.id} className="border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)] flex items-center gap-3"><div className="flex-1 min-w-0"><b className="block truncate leading-6">{s.name}</b><p className="text-[12px] text-[var(--muted)]">فصل {s.className} • ولي الأمر: {s.guardian}</p></div><button onClick={() => restoreArchivedStudent(s)} disabled={busy} className="shrink-0 px-3 py-2 rounded-full bg-[var(--green)] text-white text-[12px] font-extrabold flex items-center gap-1 disabled:opacity-60"><ArchiveRestore size={14} /> استرجاع</button></article>)}</div>}</div>}</div>
            <div className="card p-4 flex gap-3 bg-[var(--primary-soft)]"><ShieldCheck size={20} className="text-[var(--primary)] shrink-0 mt-0.5" /><p className="text-[13px] leading-6 font-bold">الدرجات الرسمية في منصة مدرستي وهذا التطبيق للمتابعة والتواصل والتقارير الأسبوعية.</p></div>
          </div>}

          {section === "contacts" && <div className="space-y-4 pop">
            <div><h1 className="text-[28px] font-black">التواصل مع أولياء الأمور</h1><p className="text-[var(--muted)] text-[13px]">أرقام من ملفات الإكسل الأربعة للفصول • تظهر مقنّعة افتراضياً، ولا تظهر كاملة إلا بعد الضغط على «إظهار الرقم».</p></div>
            <ContactSection students={contactFilteredAll} total={ALL_STUDENTS.length} phones={excelPhones} revealed={revealed} onToggle={toggleReveal} onCopy={copyPhone} search={contactSearch} onSearch={setContactSearch} loading={phonesLoading} error={phonesError} />
          </div>}

          {section === "class" && <div className="space-y-4 pop">
            <button onClick={() => setSection("classes")} className="flex items-center gap-1 text-[13px] font-extrabold text-[var(--primary)]"><ChevronLeft size={16} /> كل الفصول</button>
            <div className="card p-5 flex flex-wrap gap-4 items-center justify-between"><div><h1 className="text-[26px] font-black">فصل {cls.name} • {cls.grade}</h1><p className="text-[var(--muted)] text-[13px]">{cls.students} ابناً • مدرسة الربيع بن زياد الابتدائية</p></div><div className="flex gap-2"><button onClick={() => { setClassTab("attendance"); }} className="bg-[var(--green)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">تسجيل الحضور</button><button onClick={() => setSection("weekly")} className="border border-[var(--line)] px-4 py-2.5 rounded-full text-[13px] font-extrabold">التحضير</button></div></div>
            <div className="flex gap-2 overflow-x-auto pb-1">{[["students", "الأبناء"], ["attendance", "الحضور"], ["followup", "المتابعة"], ["prep", "التحضير"], ["contact", "التواصل"]].map(([id, label]) => <button key={id} onClick={() => setClassTab(id)} className={`px-4 py-2.5 rounded-full text-[13px] font-extrabold whitespace-nowrap ${classTab === id ? "bg-[var(--primary)] text-white" : "bg-white border border-[var(--line)]"}`}>{label}</button>)}</div>
            {classTab === "students" && <StudentTable students={classStudents} onOpen={openStudent} showGuardian />}
            {classTab === "attendance" && <AttendancePanel students={classStudents} attendance={attendance} setAttendance={setAttendance} counts={attCounts} onSave={saveAttendance} busy={busy} saveInfo={saveInfo} phones={excelPhones} onCopyText={copyText} absenceMessageFor={absenceMessageFor} showAbsenceFor={showAbsenceMsgFor} setShowAbsenceFor={setShowAbsenceMsgFor} />}
            {classTab === "followup" && <FollowupPanel students={classStudents} grades={grades} setGrades={setGrades} editing={editingGrade} setEditing={setEditingGrade} draft={gradeDraft} setDraft={setGradeDraft} onSave={saveGrades} busy={busy} />}
            {classTab === "contact" && <ContactSection students={contactFilteredClass} total={classStudents.length} phones={excelPhones} revealed={revealed} onToggle={toggleReveal} onCopy={copyPhone} search={contactSearch} onSearch={setContactSearch} loading={phonesLoading} error={phonesError} />}
            {classTab === "prep" && <div className="card p-5"><h3 className="font-black">تحضير فصل {cls.name}</h3><p className="text-[13px] text-[var(--muted)] mt-1">الأهداف، الوسائل، والأنشطة — جاهزة للتعديل والمتابعة.</p><div className="grid sm:grid-cols-3 gap-3 mt-4">{[["الهدف", "أن يجمع ابني عددين حتى 20 بدقة."], ["الوسيلة", "مكعبات عدّ، بطاقات مصوّرة، سبورة تفاعلية."], ["التقويم", "أسئلة شفهية + ورقة عمل قصيرة في نهاية الحصة."]].map(([t, d]) => <div key={t} className="bg-[var(--bg)] rounded-2xl p-4"><b className="text-[var(--primary)]">{t}</b><p className="text-[13px] leading-6 mt-1">{d}</p></div>)}</div><button onClick={() => setSection("weekly")} className="mt-4 bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">فتح التحضير الأسبوعي</button></div>}
          </div>}

          {section === "attendance" && <div className="space-y-4 pop"><div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">الحضور والغياب</h1><p className="text-[var(--muted)] text-[13px]">اختر الفصل ثم اضغط على حالة كل ابن. نسبة حضور اليوم: {todayPct}%.</p></div><select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="bg-white border border-[var(--line)] rounded-full px-4 py-2.5 font-extrabold text-[13px]">{CLASSES.map((c) => <option key={c.id} value={c.id}>فصل {c.name} • {c.students} ابناً</option>)}</select></div><AttendancePanel students={classStudents} attendance={attendance} setAttendance={setAttendance} counts={attCounts} onSave={saveAttendance} busy={busy} saveInfo={saveInfo} phones={excelPhones} onCopyText={copyText} absenceMessageFor={absenceMessageFor} showAbsenceFor={showAbsenceMsgFor} setShowAbsenceFor={setShowAbsenceMsgFor} /></div>}

          {section === "followup" && <div className="space-y-4 pop"><div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">سجلات المتابعة</h1><p className="text-[var(--muted)] text-[13px]">اضغط على أي درجة لتعديلها بالكتابة، وسيتحدّث المجموع فوراً.</p></div><select value={selectedClass} onChange={(e) => setSelectedClass(e.target.value)} className="bg-white border border-[var(--line)] rounded-full px-4 py-2.5 font-extrabold text-[13px]">{CLASSES.map((c) => <option key={c.id} value={c.id}>فصل {c.name}</option>)}</select></div><FollowupPanel students={classStudents} grades={grades} setGrades={setGrades} editing={editingGrade} setEditing={setEditingGrade} draft={gradeDraft} setDraft={setGradeDraft} onSave={saveGrades} busy={busy} /></div>}

          {section === "questions" && <div className="space-y-4 pop"><div><h1 className="text-[28px] font-black">بنك الأسئلة</h1><p className="text-[var(--muted)] text-[13px]">كوّن اختبارك بإضافة الأسئلة إلى «اختبارك الحالي».</p></div><div className="grid lg:grid-cols-3 gap-4 items-start"><div className="lg:col-span-2 space-y-3"><div className="card p-4 flex flex-wrap gap-3"><label className="flex-1 min-w-[150px]"><span className="text-[12px] font-bold text-[var(--muted)]">المادة</span><select value={qSubject} onChange={(e) => setQSubject(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>الكل</option><option>رياضيات</option><option>علوم</option><option>لغة عربية</option></select></label><label className="flex-1 min-w-[150px]"><span className="text-[12px] font-bold text-[var(--muted)]">الصف</span><select value={qGrade} onChange={(e) => setQGrade(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>الكل</option><option>الصف الأول</option><option>الصف الثالث</option></select></label></div>{filteredQs.map((q) => <article key={q.id} className="card p-4 flex gap-3 items-start"><span className="w-10 h-10 rounded-xl bg-[var(--primary-soft)] text-[var(--primary)] grid place-items-center font-black shrink-0">{q.type === "مقالي" ? "✍️" : q.type === "صح وخطأ" ? "✓✗" : "◉"}</span><div className="flex-1 min-w-0"><p className="font-extrabold leading-7">{q.text}</p><p className="text-[12px] text-[var(--muted)] mt-1">{q.subject} • {q.grade} • {q.type} • مستوى {q.level}</p></div><button onClick={() => { if (!testQs.find((x) => x.id === q.id)) { setTestQs([...testQs, q]); flash("أُضيف السؤال لاختبارك الحالي"); } else flash("السؤال موجود بالفعل في الاختبار"); }} className="shrink-0 bg-[var(--primary)] text-white px-3 py-2 rounded-full text-[12px] font-extrabold">+ إضافة للاختبار</button></article>)}{filteredQs.length === 0 && <p className="card p-6 text-center text-[var(--muted)] font-bold">لا توجد أسئلة مطابقة — جرّب فلتراً آخر.</p>}</div><aside className="card p-5 lg:sticky lg:top-[86px]"><h3 className="font-black flex items-center gap-2"><ListChecks size={19} className="text-[var(--primary)]" /> اختبارك الحالي</h3><p className="text-[12px] text-[var(--muted)] mt-1">{testQs.length} أسئلة • جاهز للمعاينة</p><div className="space-y-2 mt-4">{testQs.map((q, i) => <div key={q.id} className="flex gap-2 items-center bg-[var(--bg)] rounded-xl p-3 text-[13px] font-bold"><span className="w-6 h-6 rounded-full bg-white grid place-items-center text-[11px] shrink-0">{i + 1}</span><span className="flex-1 min-w-0 truncate">{q.text}</span><button onClick={() => setTestQs(testQs.filter((x) => x.id !== q.id))} className="text-rose-500 shrink-0" aria-label="حذف سؤال"><Trash2 size={16} /></button></div>)}</div><button onClick={() => setShowTestPreview(true)} className="w-full mt-4 bg-[var(--green)] text-white py-3 rounded-xl font-extrabold flex items-center justify-center gap-2"><Eye size={17} /> معاينة الاختبار</button><button onClick={() => { setTestQs([]); flash("تم مسح الاختبار الحالي"); }} className="w-full mt-2 py-2.5 rounded-xl font-extrabold text-[13px] border border-[var(--line)]">مسح الاختبار</button></aside></div></div>}

          {section === "weekly" && <div className="space-y-4 pop"><div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">التحضير الأسبوعي</h1><p className="text-[var(--muted)] text-[13px]">الأحد إلى الخميس • عدّل أي درس بالضغط عليه.</p></div><button onClick={autoFillWeek} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-2"><Sparkles size={16} /> تحضير تلقائي</button></div><div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{WEEK_DAYS.map((day) => <div key={day} className="card p-4"><div className="flex justify-between items-center"><h3 className="font-black">{day}</h3><span className="chip bg-[var(--bg)]">{week[day]?.length || 0} دروس</span></div><div className="space-y-2 mt-3">{(week[day] || []).map((l, i) => <div key={i} className="bg-[var(--bg)] rounded-xl p-3 flex gap-2 items-start"><span className="text-[11px] font-black bg-white px-2 py-1 rounded-full shrink-0 num">{l.time}</span><div className="flex-1 min-w-0"><p className="font-extrabold text-[13px] leading-5">{l.title}</p><p className="text-[11px] text-[var(--muted)]">فصل {l.cls}</p></div><button onClick={() => { setEditingLesson({ day, idx: i }); setLessonDraft(l.title); }} className="text-[var(--primary)] shrink-0" aria-label="تعديل الدرس"><Pencil size={15} /></button></div>)}</div><button onClick={() => { setEditingLesson({ day, idx: -1 }); setLessonDraft(""); }} className="w-full mt-3 py-2 rounded-xl border border-dashed border-[var(--line)] text-[12px] font-extrabold text-[var(--muted)]">+ إضافة درس</button></div>)}</div></div>}

          {section === "reports" && <div className="space-y-4 pop"><div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">التقارير</h1><p className="text-[var(--muted)] text-[13px]">تقارير بأسماء حقيقية من الفصل المختار.</p></div><select value={reportClass} onChange={(e) => setReportClass(e.target.value)} className="bg-white border border-[var(--line)] rounded-full px-4 py-2.5 font-extrabold text-[13px]">{CLASSES.map((c) => <option key={c.id} value={c.id}>فصل {c.name} • {c.students} ابناً</option>)}</select></div><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[{ id: "att", t: "تقرير حضور فصل", d: "حالة كل ابن اليوم: حاضر أو غائب أو متأخر.", icon: "📊", c: "#6D28D9" }, { id: "follow", t: "تقرير متابعة فصل", d: "درجات الواجب والمشاركة والسلوك لكل ابن.", icon: "📝", c: "#10B981" }, { id: "top", t: "تقرير ابني المتميز", d: "أعلى الأبناء مجموعاً في سجل المتابعة.", icon: "🏆", c: "#F59E0B" }].map((r) => <button key={r.id} onClick={() => setReport(r.id)} className="card p-5 text-start hover:-translate-y-0.5"><span className="text-3xl">{r.icon}</span><h3 className="font-black text-[17px] mt-3">{r.t} {reportClass}</h3><p className="text-[13px] text-[var(--muted)] leading-6 mt-1">{r.d}</p><span className="inline-flex items-center gap-1 mt-4 font-extrabold text-[13px]" style={{ color: r.c }}>عرض المعاينة <ChevronLeft size={15} /></span></button>)}</div><div className="card p-5 bg-[var(--primary-soft)] flex flex-wrap items-center gap-3"><div className="flex-1 min-w-[200px]"><h3 className="font-black">هل تريد التقرير الأسبوعي لكل طالب مع رسائل واتساب؟</h3><p className="text-[12.5px] text-[var(--muted)] mt-1">انتقل إلى قسم التقرير الأسبوعي الجديد.</p></div><button onClick={() => setSection("weekly-report")} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold">فتح التقرير الأسبوعي</button></div></div>}

          {section === "evidence" && <div className="space-y-4 pop"><div className="flex flex-wrap justify-between gap-3"><div><h1 className="text-[28px] font-black">شواهد الأداء</h1><p className="text-[var(--muted)] text-[13px]">وثّق عملك أولاً بأول — فكل شاهد يروي قصة جهدك مع أبنائك.</p></div><button onClick={() => setShowEvidenceForm(!showEvidenceForm)} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5"><Plus size={16} /> إضافة شاهد</button></div>
            {showEvidenceForm && <div className="card p-5 space-y-3 pop"><h3 className="font-black">شاهد جديد</h3><label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">عنوان الشاهد</span><input value={evTitle} onChange={(e) => setEvTitle(e.target.value)} placeholder="مثال: تحضير درس الكسور" className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3 font-bold text-[14px]" /></label><div className="grid sm:grid-cols-2 gap-3"><label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">نوع الشاهد</span><select value={evKind} onChange={(e) => setEvKind(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3 font-bold text-[14px]"><option>تحضير الدروس</option><option>خطط علاجية</option><option>سجلات متابعة</option><option>أنشطة إثرائية</option></select></label><label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">وصف مختصر</span><input value={evDesc} onChange={(e) => setEvDesc(e.target.value)} placeholder="ماذا تضمّن هذا الشاهد؟" className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3 text-[14px]" /></label></div><div className="flex gap-2"><button onClick={addEvidence} disabled={busy} className="bg-[var(--green)] text-white px-5 py-3 rounded-xl font-extrabold disabled:opacity-60">{busy ? "جارٍ الحفظ…" : "إضافة للقائمة"}</button><button onClick={() => setShowEvidenceForm(false)} className="px-4 py-3 rounded-xl font-extrabold border border-[var(--line)]">إلغاء</button></div></div>}
            <div className="grid sm:grid-cols-2 gap-4">{evidence.map((e) => <article key={e.id} className="card p-5"><div className="flex justify-between gap-2"><span className="chip bg-[var(--primary-soft)] text-[var(--primary)]">{e.kind}</span><span className="text-[12px] text-[var(--muted)] font-bold">{e.date}{e.pending ? " • بانتظار المزامنة" : ""}</span></div><h3 className="font-black text-[17px] mt-3 leading-7">{e.title}</h3><p className="text-[13px] text-[var(--muted)] leading-6 mt-1">{e.desc}</p><div className="flex gap-2 mt-4"><button onClick={() => flash("تم فتح معاينة الشاهد")} className="px-3 py-2 rounded-full bg-[var(--bg)] text-[12px] font-extrabold flex items-center gap-1"><Eye size={14} /> معاينة</button><button onClick={() => { setEvidence(evidence.filter((x) => x.id !== e.id)); flash("تم حذف الشاهد من القائمة"); }} className="px-3 py-2 rounded-full bg-rose-50 text-rose-600 text-[12px] font-extrabold flex items-center gap-1"><Trash2 size={14} /> حذف</button></div></article>)}</div></div>}
        </main>
      </div>

      {selectedStudent && <div className="fixed inset-0 z-50 grid place-items-center p-4"><div className="absolute inset-0 bg-black/45" onClick={() => setSelectedStudent(null)} /><div className="relative card w-full max-w-[620px] p-0 overflow-hidden pop max-h-[90vh] overflow-y-auto"><div className="bg-gradient-to-l from-violet-700 to-emerald-500 text-white p-5"><div className="flex justify-between"><span className="chip bg-white/20 text-white">فصل {selectedStudent.className} • {selectedStudent.status}</span><button onClick={() => setSelectedStudent(null)} className="w-8 h-8 grid place-items-center rounded-full bg-white/20"><X size={17} /></button></div><div className="flex items-center gap-3 mt-4"><div className="w-14 h-14 rounded-full bg-white text-violet-700 grid place-items-center text-2xl font-black shrink-0">{selectedStudent.name[0]}</div><div className="min-w-0"><h3 className="text-[21px] font-black leading-7">{selectedStudent.name}</h3><p className="text-violet-100 text-[13px]">ابني • {selectedStudent.school}</p></div></div></div>
        <div className="p-5 space-y-5">
          <div className="grid grid-cols-2 gap-3 text-[13px]"><div className="bg-[var(--bg)] rounded-2xl p-3"><p className="text-[var(--muted)] font-bold">ولي الأمر</p><p className="font-extrabold mt-1 leading-6">{selectedStudent.guardian}</p></div><div className="bg-[var(--bg)] rounded-2xl p-3"><p className="text-[var(--muted)] font-bold">الفصل والمدرسة</p><p className="font-extrabold mt-1 leading-6">فصل {selectedStudent.className}<br />{selectedStudent.school}</p></div></div>
          <div className="grid grid-cols-3 gap-3 text-center">{[["حضور اليوم", attendance[selectedStudent.id] || "حاضر"], ["الواجب", `${grades[selectedStudent.id]?.h || 0} / 10`], ["المشاركة", `${grades[selectedStudent.id]?.p || 0} / 10`]].map(([l, v]) => <div key={l} className="bg-[var(--bg)] rounded-2xl p-3"><p className="font-black text-[16px] num">{v}</p><p className="text-[12px] text-[var(--muted)] font-bold">{l}</p></div>)}</div>
          <div><h4 className="font-black mb-2">درجات المتابعة — قابلة للتعديل</h4><div className="grid grid-cols-3 gap-3">{(["h", "p", "b"] as const).map((k, idx) => <label key={k} className="block bg-[var(--bg)] rounded-2xl p-3 text-center"><span className="text-[12px] font-bold text-[var(--muted)]">{idx === 0 ? "الواجب" : idx === 1 ? "المشاركة" : "السلوك"} / 10</span><input type="number" min={0} max={10} value={grades[selectedStudent.id]?.[k] ?? 0} onChange={(e) => { const n = Math.max(0, Math.min(10, Number(e.target.value || 0))); setGrades((p) => ({ ...p, [selectedStudent.id]: { ...p[selectedStudent.id], [k]: n } })); }} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-2 py-2 text-center font-black num" /></label>)}</div><p className="text-[12px] text-[var(--muted)] font-bold mt-2">المجموع: {(grades[selectedStudent.id]?.h || 0) + (grades[selectedStudent.id]?.p || 0) + (grades[selectedStudent.id]?.b || 0)} / 30</p></div>
          <ContactBlock student={selectedStudent} phone={selectedPhone} revealed={!!revealed[selectedStudent.id]} onToggle={() => toggleReveal(selectedStudent.id)} onCopy={() => selectedPhone && copyPhone(selectedPhone)} loading={phonesLoading} error={phonesError} />
          {/* سجل النمو */}
          <div className="border border-amber-200 bg-amber-50/60 rounded-2xl p-4">
            <h4 className="font-black flex items-center gap-2"><TrendingUp size={17} className="text-amber-600" /> سجل النمو</h4>
            <p className="text-[12.5px] text-[var(--muted)] mt-1">جملة نمو تظهر في التقرير الأسبوعي — قابلة للتحرير.</p>
            <textarea value={growthNotes[selectedStudent.id] || ""} onChange={(e) => setGrowthNotes(p => ({ ...p, [selectedStudent.id]: e.target.value }))} placeholder="مثال: في بداية الفصل كان يقرأ بصعوبة وتردد، والآن صار يقرأ جملاً كاملة بثقة ويشارك بابتسامة." rows={2} className="w-full mt-2 bg-white border border-[var(--line)] rounded-2xl px-3 py-3 text-[13.5px] leading-6" />
            <button onClick={saveGrowth} disabled={busy} className="mt-2 bg-amber-500 text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold disabled:opacity-60">حفظ سجل النمو</button>
          </div>
          {/* خطتي */}
          <div className="border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)]">
            <h4 className="font-black flex items-center gap-2"><Target size={17} className="text-[var(--primary)]" /> خطتي — علاجية أو إثرائية</h4>
            <p className="text-[12.5px] text-[var(--muted)] mt-1">{(grades[selectedStudent.id]?.h || 0) + (grades[selectedStudent.id]?.p || 0) + (grades[selectedStudent.id]?.b || 0) >= 25 ? "ابنك متفوق — ستظهر خطة إثرائية مقترحة." : "اختر مهارة ضعيفة لتظهر خطة علاجية جاهزة."}</p>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">نوع الخطة</span><div className="flex gap-2 mt-1"><button onClick={() => { setPlanKind("علاجية"); const t = PLAN_TEMPLATES[planSkill] || PLAN_TEMPLATES["قراءة"]; setPlanGoal(t.goal); setPlanActivities(t.activities.join("\n")); setPlanWorksheet(t.worksheet); setPlanHome(t.homeHelp); }} className={`flex-1 py-2.5 rounded-xl font-extrabold text-[13px] ${planKind === "علاجية" ? "bg-[var(--primary)] text-white" : "bg-white border border-[var(--line)]"}`}>علاجية</button><button onClick={() => { setPlanKind("إثرائية"); setPlanGoal(ENRICHMENT_TEMPLATE.goal); setPlanActivities(ENRICHMENT_TEMPLATE.activities.join("\n")); setPlanWorksheet(ENRICHMENT_TEMPLATE.worksheet); setPlanHome(ENRICHMENT_TEMPLATE.homeHelp); }} className={`flex-1 py-2.5 rounded-xl font-extrabold text-[13px] ${planKind === "إثرائية" ? "bg-[var(--green)] text-white" : "bg-white border border-[var(--line)]"}`}>إثرائية</button></div></label>
              <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">المهارة</span><select value={planSkill} onChange={(e) => { setPlanSkill(e.target.value); if (planKind === "علاجية") { const t = PLAN_TEMPLATES[e.target.value]; setPlanGoal(t.goal); setPlanActivities(t.activities.join("\n")); setPlanWorksheet(t.worksheet); setPlanHome(t.homeHelp); } }} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]">{SKILLS.map(s => <option key={s}>{s}</option>)}</select></label>
            </div>
            <label className="block mt-3"><span className="text-[12px] font-bold text-[var(--muted)]">الهدف — قابل للتحرير</span><textarea value={planGoal} onChange={(e) => setPlanGoal(e.target.value)} rows={2} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 text-[13.5px] leading-6" /></label>
            <label className="block mt-3"><span className="text-[12px] font-bold text-[var(--muted)]">3 أنشطة — كل نشاط في سطر</span><textarea value={planActivities} onChange={(e) => setPlanActivities(e.target.value)} rows={3} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 text-[13.5px] leading-6" /></label>
            <div className="grid sm:grid-cols-2 gap-3 mt-3">
              <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">ورقة عمل مقترحة</span><textarea value={planWorksheet} onChange={(e) => setPlanWorksheet(e.target.value)} rows={2} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 text-[13px] leading-6" /></label>
              <label className="block"><span className="text-[12px] font-bold text-[var(--muted)]">كيف يساعد ولي الأمر في البيت</span><textarea value={planHome} onChange={(e) => setPlanHome(e.target.value)} rows={2} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 text-[13px] leading-6" /></label>
            </div>
            <div className="flex flex-wrap gap-3 items-center mt-3">
              <label className="flex-1 min-w-[150px]"><span className="text-[12px] font-bold text-[var(--muted)]">حالة الخطة</span><select value={planStatus} onChange={(e) => setPlanStatus(e.target.value)} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>قيد التنفيذ</option><option>تحسّن</option><option>مكتمل</option></select></label>
              <label className="flex-[2] min-w-[180px]"><span className="text-[12px] font-bold text-[var(--muted)]">شريط التقدم: {planProgress}% — المدة: أسبوعان</span><input type="range" min={0} max={100} value={planProgress} onChange={(e) => setPlanProgress(Number(e.target.value))} className="w-full mt-2 accent-[#6D28D9]" /></label>
            </div>
            <div className="w-full bg-white rounded-full h-3 mt-2 overflow-hidden border border-[var(--line)]"><div className="h-full bg-gradient-to-l from-violet-600 to-emerald-500 transition-all" style={{ width: `${planProgress}%` }} /></div>
            <div className="flex flex-wrap gap-2 mt-4">
              <button onClick={savePlan} disabled={busy} className="bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold disabled:opacity-60 flex items-center gap-1.5"><Save size={15} /> حفظ الخطة</button>
              <button onClick={() => copyText(planMessageFor(selectedStudent), "تم نسخ رسالة الخطة")} className="px-4 py-2.5 rounded-full bg-white border border-[var(--line)] text-[13px] font-extrabold flex items-center gap-1.5"><Copy size={15} /> نسخ رسالة الخطة</button>
              {selectedPhone ? <a href={waLink(selectedPhone, planMessageFor(selectedStudent))} target="_blank" rel="noopener" className="px-4 py-2.5 rounded-full bg-[var(--green)] text-white text-[13px] font-extrabold flex items-center gap-1.5"><MessageCircle size={15} /> إرسال الخطة لولي الأمر</a> : <span className="text-[12px] text-[var(--muted)] font-bold py-2">لا يوجد رقم مسجّل.</span>}
            </div>
          </div>
          <div><h4 className="font-black mb-2">ملاحظة المعلم عنه</h4><textarea value={notes[selectedStudent.id] || ""} onChange={(e) => setNotes((p) => ({ ...p, [selectedStudent.id]: e.target.value }))} placeholder="اكتب ملاحظتك عن ابنك هنا…" rows={3} className="w-full bg-[var(--bg)] border border-[var(--line)] rounded-2xl px-3 py-3 text-[13.5px] leading-6" /><button onClick={saveNote} disabled={busy} className="mt-2 bg-[var(--primary)] text-white px-4 py-2.5 rounded-full text-[13px] font-extrabold disabled:opacity-60">{busy ? "جارٍ الحفظ…" : "حفظ الملاحظة"}</button></div>
          <div><button onClick={() => setShowMessage(!showMessage)} className="w-full bg-[var(--green)] text-white py-3 rounded-xl font-extrabold flex items-center justify-center gap-2"><MessageCircle size={17} /> رسالة لولي الأمر</button>
          {showMessage && <div className="mt-3 border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)]"><label className="block text-[12px] font-bold text-[var(--muted)]">نوع الرسالة</label><select value={messageKind} onChange={(e) => setMessageKind(e.target.value)} className="w-full mt-1 bg-white border border-[var(--line)] rounded-xl px-3 py-2.5 font-bold text-[13px]"><option>تقدير</option><option>متابعة واجب</option><option>دعوة تواصل</option></select><p className="text-[12px] text-[var(--muted)] mt-2">نص جاهز لولي الأمر — {selectedStudent.guardian} — بدون إظهار أي رقم:</p><p className="whitespace-pre-line text-[13.5px] leading-7 bg-white rounded-xl p-3 mt-2 border border-[var(--line)]">{guardianMessage}</p></div>}</div>
          <div className="grid sm:grid-cols-2 gap-2">
            <button onClick={() => { setSelectedStudent(null); setWeeklyClass(selectedStudent.className); setWeeklyStudentId(selectedStudent.id); setSection("weekly-report"); }} className="bg-[var(--ink)] text-white py-3 rounded-xl font-extrabold">فتح تقريره الأسبوعي</button>
            <button onClick={() => { setSelectedStudent(null); setSelectedClass(selectedStudent.className); setSection("followup"); }} className="py-3 rounded-xl font-extrabold border border-[var(--line)]">فتح سجل متابعة فصله</button>
          </div>
        </div></div></div>}

      {report && <div className="fixed inset-0 z-50 grid place-items-center p-4"><div className="absolute inset-0 bg-black/45" onClick={() => setReport(null)} /><div className="relative card w-full max-w-[640px] max-h-[90vh] overflow-y-auto p-6 pop"><div className="flex justify-between items-start"><div><p className="text-[12px] font-bold text-[var(--muted)]">متابعتي لأبنائي • مدرسة الربيع بن زياد الابتدائية</p><h3 className="text-[21px] font-black mt-1">{report === "att" ? `تقرير حضور فصل ${reportClass}` : report === "follow" ? `تقرير متابعة فصل ${reportClass}` : `تقرير ابني المتميز — فصل ${reportClass}`}</h3><p className="text-[13px] text-[var(--muted)]">أ. عبدالعزيز • {reportStudents.length} ابناً • اليوم {new Date().toLocaleDateString("ar-SA")}</p></div><button onClick={() => setReport(null)} className="w-9 h-9 grid place-items-center rounded-full bg-[var(--bg)] shrink-0"><X size={18} /></button></div>
        {report === "top" ? <div className="space-y-3 mt-5">{topStudents.map((s, i) => <div key={s.id} className="flex items-center gap-3 bg-[var(--bg)] rounded-2xl p-3"><span className="w-9 h-9 rounded-full bg-amber-100 text-amber-700 grid place-items-center font-black shrink-0">{i + 1}</span><div className="flex-1 min-w-0"><p className="font-extrabold truncate">{s.name}</p><p className="text-[12px] text-[var(--muted)]">ولي الأمر: {s.guardian}</p></div><span className="chip bg-emerald-50 text-emerald-700 shrink-0">{grades[s.id].h + grades[s.id].p + grades[s.id].b} / 30</span></div>)}<p className="text-[13px] leading-6 text-[var(--muted)]">نفخر بأبنائنا المتميزين، ونواصل دعم كل ابنٍ ليصل إلى أفضل ما لديه.</p></div>
        : <div className="mt-5 border border-[var(--line)] rounded-2xl overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-[13px] min-w-[520px]"><thead className="bg-[var(--bg)]"><tr><th className="p-3 text-start">الابن</th><th className="p-3 text-start">ولي الأمر</th><th className="p-3 text-start">{report === "att" ? "حالة اليوم" : "المجموع / 30"}</th></tr></thead><tbody>{reportStudents.map((s) => <tr key={s.id} className="border-t border-[var(--line)]"><td className="p-3 font-bold">{s.name}</td><td className="p-3">{s.guardian}</td><td className="p-3 font-black">{report === "att" ? (attendance[s.id] || "حاضر") : `${grades[s.id].h + grades[s.id].p + grades[s.id].b}`}</td></tr>)}</tbody></table></div></div>}
        <button onClick={() => setReport(null)} className="w-full mt-4 bg-[var(--ink)] text-white py-3 rounded-xl font-extrabold">إغلاق المعاينة</button></div></div>}

      {showTestPreview && <Modal onClose={() => setShowTestPreview(false)} title="معاينة الاختبار"><p className="text-[13px] text-[var(--muted)]">اختبار {testQs[0]?.subject || "عام"} • {testQs.length} أسئلة • الزمن المقترح 30 دقيقة</p><div className="space-y-4 mt-4">{testQs.map((q, i) => <div key={q.id} className="border border-[var(--line)] rounded-2xl p-4"><p className="font-extrabold">س{i + 1}: {q.text}</p><p className="text-[12px] text-[var(--muted)] mt-1">({q.type})</p></div>)}</div>{testQs.length === 0 && <p className="text-center text-[var(--muted)] font-bold py-6">اختر أسئلة أولاً من بنك الأسئلة.</p>}</Modal>}
      {showNewSession && <Modal onClose={() => setShowNewSession(false)} title="حصة جديدة"><p className="text-[13px] text-[var(--muted)]">ابدأ حصة الآن وسيُسجَّل حضورها تلقائياً.</p><div className="grid grid-cols-2 gap-3 mt-4">{CLASSES.map((c) => <button key={c.id} onClick={() => { setSelectedClass(c.id); setShowNewSession(false); setSection("attendance"); flash(`بدأت حصة فصل ${c.name}`); }} className="border border-[var(--line)] rounded-2xl p-4 text-start hover:border-[var(--primary)]"><b>فصل {c.name}</b><p className="text-[12px] text-[var(--muted)]">{c.grade} • {c.students} ابناً</p></button>)}</div></Modal>}
      {showNewPrep && <Modal onClose={() => setShowNewPrep(false)} title="تحضير جديد"><label className="block text-[12px] font-bold text-[var(--muted)]">عنوان الدرس</label><input value={newPrepTitle} onChange={(e) => setNewPrepTitle(e.target.value)} placeholder="مثال: درس الكسور البسيطة" className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3" /><label className="block mt-3 text-[12px] font-bold text-[var(--muted)]">اليوم</label><select value={newPrepDay} onChange={(e) => setNewPrepDay(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3">{WEEK_DAYS.map((d) => <option key={d}>{d}</option>)}</select><button onClick={() => { if (!newPrepTitle.trim()) { flash("اكتب عنوان الدرس"); return; } setWeek({ ...week, [newPrepDay]: [...(week[newPrepDay] || []), { time: "09:00", title: newPrepTitle.trim(), cls: "اول/4" }] }); setNewPrepTitle(""); setShowNewPrep(false); setSection("weekly"); flash("تمت إضافة التحضير الجديد"); }} className="w-full mt-4 bg-[var(--primary)] text-white py-3 rounded-xl font-extrabold">إضافة التحضير</button></Modal>}
      {editingLesson && <Modal onClose={() => setEditingLesson(null)} title={editingLesson.idx === -1 ? "إضافة درس" : "تعديل الدرس"}><label className="block text-[12px] font-bold text-[var(--muted)]">عنوان الدرس — {editingLesson.day}</label><input value={lessonDraft} onChange={(e) => setLessonDraft(e.target.value)} className="w-full mt-1 bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-3" autoFocus /><div className="flex gap-2 mt-4"><button onClick={() => { if (!lessonDraft.trim()) { flash("اكتب عنوان الدرس"); return; } const copy = { ...week }; const arr = [...(copy[editingLesson.day] || [])]; if (editingLesson.idx === -1) arr.push({ time: "09:00", title: lessonDraft.trim(), cls: "اول/4" }); else arr[editingLesson.idx] = { ...arr[editingLesson.idx], title: lessonDraft.trim() }; copy[editingLesson.day] = arr; setWeek(copy); setEditingLesson(null); flash("تم حفظ الدرس"); }} className="flex-1 bg-[var(--primary)] text-white py-3 rounded-xl font-extrabold">حفظ</button>{editingLesson.idx >= 0 && <button onClick={() => { const copy = { ...week }; copy[editingLesson.day] = copy[editingLesson.day].filter((_, i) => i !== editingLesson.idx); setWeek(copy); setEditingLesson(null); flash("تم حذف الدرس"); }} className="px-4 py-3 rounded-xl bg-rose-50 text-rose-600 font-extrabold">حذف</button>}</div></Modal>}

      {showPresentation && (
        <div className="fixed inset-0 z-[80] overflow-y-auto" dir="rtl" style={{ backgroundImage: `linear-gradient(rgba(255,255,255,0.92), rgba(255,255,255,0.92)), url(${schoolImageUrl})`, backgroundSize: "cover", backgroundPosition: "center", backgroundRepeat: "no-repeat" }}>
          <div className="min-h-full flex flex-col mx-auto max-w-[1080px] px-4 sm:px-6 py-4 sm:py-6">
            <div className="flex flex-wrap items-center gap-2 sm:gap-3">
              <span className="inline-flex items-center gap-1.5 bg-[#F59E0B] text-white px-4 py-2 rounded-full text-[13px] font-black shadow-lg shadow-amber-200"><Crown size={16} /> وضع العرض للإدارة</span>
              <span className="chip bg-white border border-[var(--line)] text-[var(--muted)]">عرض عام • بدون بيانات خاصة</span>
              <button onClick={() => setShowPresentation(false)} className="ms-auto bg-white border border-[var(--line)] px-4 py-2.5 rounded-full text-[13px] font-extrabold flex items-center gap-1.5 shadow-sm"><X size={16} /> الخروج من وضع العرض</button>
            </div>
            <div className="mt-5 bg-white rounded-full h-3 overflow-hidden border border-[var(--line)] shadow-sm" role="progressbar" aria-valuenow={slide + 1} aria-valuemin={1} aria-valuemax={6} aria-label={`الشاشة ${slide + 1} من 6`}>
              <div className="h-full bg-gradient-to-l from-[#6D28D9] via-[#F59E0B] to-[#10B981] transition-all" style={{ width: `${((slide + 1) / 6) * 100}%` }} />
            </div>
            <div className="flex items-center justify-between gap-2 mt-3 flex-wrap">
              <p className="font-black text-[15px] sm:text-[17px]">الشاشة {slide + 1} من 6</p>
              <div className="flex gap-1.5 flex-wrap">{["الغلاف", "لوحة التحكم", "قصة الغياب", "التقرير الأسبوعي", "لوحة الشرف", "الخلاصة"].map((t, i) => <span key={t} className={`px-3 py-1.5 rounded-full text-[12px] font-extrabold border ${i === slide ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-white border-[var(--line)] text-[var(--muted)]"}`}>{i + 1}. {t}</span>)}</div>
            </div>

            <div className="flex-1 py-5 sm:py-7">
              {slide === 0 && <div className="space-y-5 pop">
                <div className="relative overflow-hidden rounded-[28px] border border-[var(--line)] shadow-[var(--shadow)]">
                  <img src={schoolImageUrl} alt="مبنى مدرسة الربيع بن زياد الابتدائية" className="absolute inset-0 h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-l from-white via-white/90 to-white/30" aria-hidden="true" />
                  <div className="relative p-6 sm:p-10 text-center sm:text-start">
                    <span className="chip bg-[#F59E0B] text-white">عرض للإدارة</span>
                    <h1 className="text-[clamp(34px,6vw,58px)] font-black leading-tight mt-4">متابعتي <span className="text-[var(--primary)]">لأبنائي</span></h1>
                    <p className="text-[20px] sm:text-[24px] font-black mt-3">أ. عبدالعزيز</p>
                    <p className="text-[16px] sm:text-[18px] font-bold text-[var(--muted)] mt-1">مدرسة الربيع بن زياد الابتدائية</p>
                    <p className="text-[16px] sm:text-[19px] leading-8 sm:leading-9 font-bold mt-5 max-w-[640px] mx-auto sm:mx-0 bg-white/80 border border-[var(--line)] rounded-2xl p-4">أداة مساعدة للمعلم للمتابعة والتواصل والتحفيز وليست بديلاً عن منصة مدرستي</p>
                    <div className="flex flex-wrap gap-2 mt-5 justify-center sm:justify-start"><span className="chip bg-white shadow">134 ابناً</span><span className="chip bg-white shadow">4 فصول</span><span className="chip bg-white shadow">متابعة • تواصل • تحفيز</span></div>
                  </div>
                </div>
                <p className="text-center text-[14px] font-bold text-[var(--muted)]">في هذا العرض تظهر الأسماء والأرقام العامة فقط — ولا تظهر أي بيانات تواصل خاصة.</p>
              </div>}

              {slide === 1 && <div className="space-y-5 pop">
                <div className="card p-6 sm:p-8 text-center sm:text-start"><p className="text-[13px] font-bold text-[var(--muted)]">نظرة عامة</p><h2 className="text-[clamp(28px,4.5vw,42px)] font-black leading-tight mt-2">لوحة التحكم — أعداد عامة فقط</h2><p className="text-[15px] text-[var(--muted)] leading-7 mt-2">صورة سريعة عن سير اليوم الدراسي، من دون تفاصيل طلاب ومن دون أي بيانات خاصة.</p></div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="card p-6 text-center"><p className="text-5xl">🎓</p><p className="text-[clamp(36px,5vw,52px)] font-black num leading-none mt-3">134</p><p className="font-black text-[17px] mt-2">ابناً</p><p className="text-[13px] text-[var(--muted)] mt-1">إجمالي أبناء المعلم</p></div>
                  <div className="card p-6 text-center"><p className="text-5xl">🏫</p><p className="text-[clamp(36px,5vw,52px)] font-black num leading-none mt-3">4</p><p className="font-black text-[17px] mt-2">فصول</p><p className="text-[13px] text-[var(--muted)] mt-1">فصول المعلم الأربعة</p></div>
                  <div className="card p-6 text-center"><p className="text-5xl">✓</p><p className="text-[clamp(36px,5vw,52px)] font-black num leading-none mt-3">{todayPct}%</p><p className="font-black text-[17px] mt-2">نسبة الحضور العامة</p><p className="text-[13px] text-[var(--muted)] mt-1">نسبة عامة لليوم فقط</p></div>
                </div>
                <div className="card p-5 flex flex-wrap gap-2 items-center justify-center"><span className="font-black">الفصول:</span>{["اول/4", "ثالث/1", "ثالث/2", "ثالث/3"].map((c) => <span key={c} className="chip bg-[var(--primary-soft)] text-[var(--primary)]">فصل {c}</span>)}<span className="text-[13px] text-[var(--muted)] font-bold">— أسماء الفصول فقط، بدون قوائم طلاب.</span></div>
              </div>}

              {slide === 2 && <div className="space-y-5 pop">
                <div className="card p-6 sm:p-8"><p className="text-[13px] font-bold text-[var(--muted)]">مثال توضيحي</p><h2 className="text-[clamp(28px,4.5vw,42px)] font-black leading-tight mt-2">قصة الغياب</h2><p className="text-[17px] leading-8 font-bold mt-3">عندما يغيب ابن، تجهز رسالة لولي أمره للاطمئنان عليه — بدون اتصال، وبدون إضاعة وقت الحصة.</p><div className="grid sm:grid-cols-3 gap-3 mt-5">{[["1", "يسجّل المعلم الغياب", "بضغطة واحدة في قائمة الفصل."], ["2", "تجهز رسالة الاطمئنان", "نص جاهز ولطيف ومحترم."], ["3", "يتابع المعلم حصته", "دون مقاطعة الشرح أو التأخير."]].map(([n, t, d]) => <div key={n} className="bg-[var(--bg)] rounded-2xl p-4"><span className="w-9 h-9 rounded-full bg-[var(--primary)] text-white grid place-items-center font-black">{n}</span><p className="font-black mt-3 leading-6">{t}</p><p className="text-[13px] text-[var(--muted)] leading-6 mt-1">{d}</p></div>)}</div></div>
                <div className="card p-6 border-[var(--green)]/40 bg-[var(--green-soft)]"><p className="font-black flex items-center gap-2">💬 نص الرسالة — مثال فقط، بدون رقم</p><p className="whitespace-pre-line text-[16px] leading-8 bg-white rounded-2xl p-4 mt-3 border border-[var(--line)]">السلام عليكم ورحمة الله،{"\n"}اليوم ابنكم غائب، طمنونا عليه، ونسأل الله له الشفاء والعافية إن كان مريضاً.{"\n"}إذا كان لديه أي ظرف، يسعدنا أن تبلغونا، وسنعوضه ما فاته بإذن الله.{"\n"}مع خالص التقدير، أ. عبدالعزيز — مدرسة الربيع بن زياد الابتدائية</p><p className="text-[13px] font-bold text-[var(--muted)] mt-3">في وضع العرض لا يظهر أي رقم جوال ولا أي زر تواصل حقيقي.</p></div>
              </div>}

              {slide === 3 && <div className="space-y-5 pop">
                <div className="card p-6 sm:p-8"><p className="text-[13px] font-bold text-[var(--muted)]">مثال توضيحي — الاسم الكامل محجوب</p><h2 className="text-[clamp(28px,4.5vw,42px)] font-black leading-tight mt-2">التقرير الأسبوعي</h2><p className="text-[15px] text-[var(--muted)] leading-7 mt-2">تقرير مختصر يلخّص أسبوع الابن لولي أمره، بلغة مشجعة وواضحة.</p></div>
                <div className="card p-6 sm:p-7">
                  <div className="flex flex-wrap justify-between gap-3 items-center"><div><h3 className="text-[24px] font-black">الابن: عبدالله <span className="text-[13px] text-[var(--muted)] font-bold">(الاسم الأول فقط — مثال)</span></h3><p className="text-[13px] text-[var(--muted)] mt-1">فصل ثالث/1 • مثال توضيحي وليس تقريراً حقيقياً لطالب بعينه</p></div><span className="chip bg-[var(--primary-soft)] text-[var(--primary)]">تقرير الأسبوع</span></div>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-5">
                    <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">الحضور</p><p className="font-black text-[22px] num mt-2">5 من 5 أيام</p></div>
                    <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">الواجبات</p><p className="font-black text-[22px] num mt-2">9 من 10</p></div>
                    <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">المشاركة</p><p className="font-black text-[22px] num mt-2">9 من 10</p></div>
                    <div className="bg-[var(--bg)] rounded-2xl p-4 text-center"><p className="text-[12px] font-bold text-[var(--muted)]">السلوك</p><p className="font-black text-[22px] num mt-2">10 من 10</p></div>
                  </div>
                  <div className="mt-4 bg-amber-50 border border-amber-200 rounded-2xl p-4"><p className="text-[15px] leading-7"><b>ملاحظة المعلم:</b> واصل تقدمه الجميل هذا الأسبوع، يشارك بثقة ويحرص على واجباته — ونحن فخورون به.</p></div>
                  <p className="text-[13px] font-bold text-[var(--muted)] mt-3">في وضع العرض لا يمكن فتح صفحة طالب كاملة ولا نسخ أي بيانات.</p>
                </div>
              </div>}

              {slide === 4 && <div className="space-y-5 pop">
                <div className="card p-6 sm:p-8 text-center sm:text-start"><p className="text-[13px] font-bold text-amber-700">✨ نحتفي بأبنائنا ✨</p><h2 className="text-[clamp(28px,4.5vw,42px)] font-black leading-tight mt-2">لوحة الشرف وابن الأسبوع</h2><p className="text-[15px] text-[var(--muted)] leading-7 mt-2">التحفيز عادة يومية: وسام صغير اليوم، يصنع ثقة كبيرة غداً.</p></div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="card p-6 text-center border-t-4 border-t-[#6D28D9]"><p className="text-5xl">📖</p><p className="chip bg-[#F0E9FF] text-[#6D28D9] mt-4 inline-block">نجم القراءة</p><p className="text-[14px] leading-6 text-[var(--muted)] mt-3">يقرأ بطلاقة وثقة، ويشارك زملاءه ما تعلّم.</p></div>
                  <div className="card p-6 text-center border-t-4 border-t-[#10B981]"><p className="text-5xl">📍</p><p className="chip bg-[#E7F9F1] text-[#10B981] mt-4 inline-block">نجم الحضور</p><p className="text-[14px] leading-6 text-[var(--muted)] mt-3">حضور كامل والتزام جميل من بداية اليوم.</p></div>
                  <div className="card p-6 text-center border-t-4 border-t-[#F59E0B]"><p className="text-5xl">💛</p><p className="chip bg-[#FEF3C7] text-[#F59E0B] mt-4 inline-block">نجم الأخلاق</p><p className="text-[14px] leading-6 text-[var(--muted)] mt-3">أخلاق جميلة وتعاون صادق مع زملائه.</p></div>
                </div>
                <div className="relative overflow-hidden rounded-[26px] border border-amber-200 shadow-[var(--shadow)]">
                  <img src={schoolImageUrl} alt="مبنى مدرسة الربيع بن زياد الابتدائية" className="absolute inset-0 h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-l from-white via-white/92 to-white/40" aria-hidden="true" />
                  <div className="relative p-6 sm:p-8 text-center"><p className="text-5xl">👑</p><p className="text-[13px] font-bold text-amber-700 mt-3">مدرسة الربيع بن زياد الابتدائية • مثال توضيحي</p><h3 className="text-[clamp(26px,4.5vw,38px)] font-black mt-2 leading-tight">فخورون بك يا بطل، أنت ابن الأسبوع</h3><p className="text-[17px] leading-8 font-bold mt-3 max-w-[620px] mx-auto">لحضوره الكامل واجتهاده ومشاركته الرائعة وأخلاقه الجميلة — واصل تألقك فأنت قدوة لزملائك.</p><p className="font-black mt-4">— أ. عبدالعزيز —</p></div>
                </div>
              </div>}

              {slide === 5 && <div className="space-y-5 pop">
                <div className="card p-6 sm:p-8 text-center sm:text-start"><p className="text-[13px] font-bold text-[var(--muted)]">الخلاصة</p><h2 className="text-[clamp(28px,4.5vw,42px)] font-black leading-tight mt-2">الخلاصة للإدارة</h2><p className="text-[15px] text-[var(--muted)] leading-7 mt-2">أربع نقاط واضحة تلخّص الفكرة والضمانات.</p></div>
                <div className="grid sm:grid-cols-2 gap-4">{[["1", "الدرجات الرسمية تبقى في مدرستي", "لا ينقل التطبيق الدرجات الرسمية ولا يحل محل المنصة."], ["2", "التطبيق للمتابعة فقط", "متابعة يومية وتواصل وتقارير وتحفيز، داخل عمل المعلم."], ["3", "البيانات محفوظة عند المعلم فقط", "بيانات التواصل لا تظهر في العرض العام، وتبقى عند المعلم."], ["4", "بدون أي تكلفة على المدرسة", "لا يطلب التطبيق من المدرسة أي مصاريف أو تجهيزات."]].map(([n, t, d]) => <div key={n} className="card p-6"><span className="w-11 h-11 rounded-full bg-[#F59E0B] text-white grid place-items-center font-black text-[18px]">{n}</span><h3 className="font-black text-[19px] leading-7 mt-3">{t}</h3><p className="text-[14px] text-[var(--muted)] leading-7 mt-1">{d}</p></div>)}</div>
                <div className="card p-6 sm:p-7 bg-[var(--primary-soft)] border-[var(--primary)]/25 text-center"><p className="text-3xl">🤝</p><h3 className="font-black text-[22px] mt-2">مقترح التجربة</h3><p className="text-[17px] leading-8 font-bold mt-2 max-w-[640px] mx-auto">مقترح: تجربة لمدة شهر في فصول المعلم الأربعة، ثم التقييم.</p><p className="text-[14px] text-[var(--muted)] leading-7 mt-2">بعد الشهر نراجع معاً: هل سهّلت المتابعة؟ وهل تحسّن التواصل والتحفيز؟ ثم نقرر الخطوة التالية.</p><button onClick={() => setShowPresentation(false)} className="mt-5 bg-[var(--primary)] text-white px-6 py-3.5 rounded-full text-[15px] font-extrabold shadow-lg shadow-violet-300">الخروج من وضع العرض والعودة للتطبيق</button></div>
              </div>}
            </div>

            <div className="sticky bottom-0 bg-white/95 backdrop-blur-md border border-[var(--line)] rounded-2xl shadow-lg p-3 flex items-center gap-2 sm:gap-3">
              <button onClick={() => setSlide((s) => Math.max(0, s - 1))} disabled={slide === 0} className="flex-1 sm:flex-none sm:px-8 py-3.5 rounded-full border border-[var(--line)] font-extrabold text-[14px] disabled:opacity-40 bg-white">السابق</button>
              <span className="hidden sm:block text-[13px] font-bold text-[var(--muted)] flex-1 text-center">الشاشة {slide + 1} من 6</span>
              {slide < 5 ? <button onClick={() => setSlide((s) => Math.min(5, s + 1))} className="flex-1 sm:flex-none sm:px-8 py-3.5 rounded-full bg-[var(--primary)] text-white font-extrabold text-[14px] shadow-lg shadow-violet-300">التالي</button> : <button onClick={() => setShowPresentation(false)} className="flex-1 sm:flex-none sm:px-8 py-3.5 rounded-full bg-[#F59E0B] text-white font-extrabold text-[14px] shadow-lg shadow-amber-200">الخروج من وضع العرض</button>}
            </div>
          </div>
        </div>
      )}
      {toast && <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[60] bg-[var(--ink)] text-white px-5 py-3 rounded-full text-[13px] font-extrabold shadow-2xl flex items-center gap-2 pop"><Check size={17} className="text-emerald-400" />{toast}</div>}
    </div>
  );
}

function PrivacyNotice() {
  return <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-2xl p-3 text-[12.5px] leading-6 font-bold text-amber-800"><ShieldAlert size={17} className="shrink-0 mt-0.5" /><span>أرقام أولياء الأمور خاصة - لا تشارك رابط التطبيق مع أحد</span></div>;
}

function ContactActions({ student, phone, revealed, onToggle, onCopy, compact = false }: { student: Student; phone?: string; revealed: boolean; onToggle: () => void; onCopy: () => void; compact?: boolean }) {
  if (!phone) return <p className="text-[12.5px] text-[var(--muted)] font-bold leading-6">لا يوجد رقم مسجّل لهذا الابن في ملفات الفصول.</p>;
  const display = revealed ? toLocalPhone(phone) : maskPhone(phone);
  const wa = `https://wa.me/${phone}?text=${encodeURIComponent(WHATSAPP_TEXT)}`;
  return <div className={compact ? "" : "space-y-3"}>
    <div className="flex flex-wrap items-center gap-2">
      <span className="font-black text-[15px] num tracking-wide" dir="ltr">{display}</span>
      <button onClick={onToggle} className="px-3 py-2 rounded-full bg-[var(--primary)] text-white text-[12px] font-extrabold flex items-center gap-1.5">{revealed ? <EyeOff size={14} /> : <Eye size={14} />}{revealed ? "إخفاء" : "إظهار الرقم"}</button>
    </div>
    <div className="flex flex-wrap gap-2">
      <a href={wa} target="_blank" rel="noopener" className="px-3.5 py-2.5 rounded-full bg-[var(--green)] text-white text-[12.5px] font-extrabold flex items-center gap-1.5"><MessageCircle size={15} /> تواصل واتساب</a>
      <button onClick={onCopy} className="px-3.5 py-2.5 rounded-full bg-white border border-[var(--line)] text-[12.5px] font-extrabold flex items-center gap-1.5"><Copy size={14} /> نسخ الرقم</button>
    </div>
  </div>;
}

function ContactBlock({ student, phone, revealed, onToggle, onCopy, loading, error }: any) {
  return <div>
    <h4 className="font-black mb-2 flex items-center gap-2"><Phone size={17} className="text-[var(--primary)]" /> التواصل مع ولي الأمر</h4>
    <div className="border border-[var(--line)] rounded-2xl p-4 bg-[var(--bg)] space-y-3">
      <PrivacyNotice />
      <div className="flex flex-wrap gap-3 text-[13px]"><span><span className="text-[var(--muted)] font-bold">ولي الأمر: </span><b>{student.guardian}</b></span><span><span className="text-[var(--muted)] font-bold">الابن: </span><b>{student.name}</b></span></div>
      {loading ? <p className="text-[12.5px] text-[var(--muted)] font-bold">جارٍ تحميل رقم التواصل من ملفات الفصول…</p> : error && !phone ? <p className="text-[12.5px] text-amber-700 font-bold">{error}</p> : <ContactActions student={student} phone={phone} revealed={revealed} onToggle={onToggle} onCopy={onCopy} />}
    </div>
  </div>;
}

function ContactSection({ students, total, phones, revealed, onToggle, onCopy, search, onSearch, loading, error }: any) {
  return <div className="space-y-4">
    <PrivacyNotice />
    <div className="card p-4 flex flex-wrap gap-3 items-center">
      <Search size={18} className="text-[var(--muted)]" />
      <input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="ابحث باسم الطالب أو باسم ولي الأمر…" className="flex-1 min-w-[180px] bg-transparent font-bold text-[14px]" />
      <span className="chip bg-[var(--bg)] text-[var(--muted)]">{students.length} من {total}</span>
    </div>
    {loading && <p className="card p-5 text-center text-[13px] text-[var(--muted)] font-bold">جارٍ تحميل أرقام التواصل من ملفات الفصول الأربعة…</p>}
    {!loading && error && Object.keys(phones).length === 0 && <p className="card p-5 text-center text-[13px] text-amber-700 font-bold">{error}</p>}
    <div className="grid sm:grid-cols-2 gap-3">
      {students.map((s: any) => {
        const phone = phones[s.id];
        const isRevealed = !!revealed[s.id];
        return <article key={s.id} className="card p-4">
          <div className="flex items-start gap-3">
            <span className="w-10 h-10 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] grid place-items-center font-black shrink-0">{s.name[0]}</span>
            <div className="flex-1 min-w-0">
              <p className="font-extrabold leading-6 truncate">{s.name}</p>
              <p className="text-[12px] text-[var(--muted)] mt-0.5">ولي الأمر: <b className="text-[var(--ink)]">{s.guardian}</b> • فصل {s.className}</p>
              <div className="mt-3">
                {loading ? <p className="text-[12.5px] text-[var(--muted)] font-bold">جارٍ التحميل…</p> : !phone ? <p className="text-[12.5px] text-[var(--muted)] font-bold">لا يوجد رقم مسجّل في ملفات الفصول.</p> : <ContactActions student={s} phone={phone} revealed={isRevealed} onToggle={() => onToggle(s.id)} onCopy={() => onCopy(phone)} compact />}
              </div>
            </div>
          </div>
        </article>;
      })}
    </div>
    {students.length === 0 && <p className="card p-8 text-center text-[var(--muted)] font-bold">لا توجد نتائج مطابقة لبحثك.</p>}
  </div>;
}

function StudentTable({ students, onOpen, showClass = false, showGuardian = false }: any) {
  return <div className="card overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-[13.5px] min-w-[620px]"><thead className="bg-[var(--bg)]"><tr><th className="p-3.5 text-start">الابن</th>{showClass && <th className="p-3.5 text-start">الفصل</th>}{showGuardian && <th className="p-3.5 text-start">ولي الأمر</th>}<th className="p-3.5 text-start">الحالة</th><th className="p-3.5 text-start">ملف ابني</th></tr></thead><tbody>{students.map((s: any) => <tr key={s.id} className="border-t border-[var(--line)]"><td className="p-3.5"><div className="flex items-center gap-2.5"><span className="w-9 h-9 rounded-full bg-[var(--primary-soft)] text-[var(--primary)] grid place-items-center font-black shrink-0">{s.name[0]}</span><b>{s.name}</b></div></td>{showClass && <td className="p-3.5">فصل {s.className}</td>}{showGuardian && <td className="p-3.5">{s.guardian}</td>}<td className="p-3.5"><span className="chip bg-emerald-50 text-emerald-700">{s.status || "منتظم"}</span></td><td className="p-3.5"><button onClick={() => onOpen(s)} className="px-3 py-2 rounded-full bg-[var(--bg)] border border-[var(--line)] font-extrabold text-[12px] flex items-center gap-1"><Eye size={14} /> ملف ابني</button></td></tr>)}</tbody></table></div>{students.length === 0 && <p className="p-8 text-center text-[var(--muted)] font-bold">لا توجد نتائج مطابقة لبحثك.</p>}</div>;
}
function AttendancePanel({ students, attendance, setAttendance, counts, onSave, busy, saveInfo, phones, onCopyText, absenceMessageFor, showAbsenceFor, setShowAbsenceFor }: any) {
  return <div className="space-y-4"><div className="grid grid-cols-3 gap-3">{[["حاضر", counts.p, "bg-emerald-50 text-emerald-700", "🟢"], ["غائب", counts.a, "bg-rose-50 text-rose-600", "🔴"], ["متأخر", counts.l, "bg-amber-50 text-amber-700", "🟡"]].map(([l, v, cls, ic]) => <div key={l as string} className={`card p-4 text-center ${cls}`}><p className="text-[26px] font-black num">{v}</p><p className="font-extrabold text-[13px]">{ic} {l}</p></div>)}</div><div className="card p-4"><div className="flex justify-between items-center mb-3"><h3 className="font-black">قائمة اليوم — {new Date().toLocaleDateString("ar-SA")}</h3><span className="text-[12px] text-[var(--muted)] font-bold">اضغط لتغيير الحالة</span></div><div className="space-y-2">{students.map((s: any) => { const cur = attendance[s.id] || "حاضر"; const isAbsent = cur === "غائب"; const msg = absenceMessageFor ? absenceMessageFor(s) : ""; const phone = phones?.[s.id]; return <div key={s.id} className="bg-[var(--bg)] rounded-2xl p-2.5"><div className="flex items-center gap-2 sm:gap-3"><span className="w-9 h-9 rounded-full bg-white grid place-items-center font-black text-[var(--primary)] shrink-0">{s.name[0]}</span><b className="flex-1 min-w-0 truncate text-[13.5px]">{s.name}</b><div className="flex gap-1.5 shrink-0">{[["حاضر", "bg-emerald-500 text-white"], ["غائب", "bg-rose-500 text-white"], ["متأخر", "bg-amber-500 text-white"]].map(([label, onCls]) => <button key={label} onClick={() => setAttendance({ ...attendance, [s.id]: label })} className={`px-2.5 sm:px-3.5 py-2 rounded-full text-[11px] sm:text-[12px] font-extrabold ${cur === label ? onCls : "bg-white border border-[var(--line)]"}`}>{label}</button>)}</div></div>{isAbsent && <div className="mt-2 flex flex-wrap items-center gap-2 ps-11"><button onClick={() => setShowAbsenceFor(showAbsenceFor === s.id ? null : s.id)} className="px-3 py-2 rounded-full bg-white border border-rose-200 text-rose-600 text-[12px] font-extrabold flex items-center gap-1"><MessageCircle size={13} /> رسالة الغياب التلقائية</button>{showAbsenceFor === s.id && <div className="w-full bg-white border border-[var(--line)] rounded-2xl p-3"><p className="whitespace-pre-line text-[12.5px] leading-6">{msg}</p><div className="flex flex-wrap gap-2 mt-2"><button onClick={() => onCopyText(msg, "تم نسخ رسالة الغياب")} className="px-3 py-2 rounded-full bg-[var(--bg)] border border-[var(--line)] text-[12px] font-extrabold flex items-center gap-1"><Copy size={13} /> نسخ</button>{phone ? <a href={`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`} target="_blank" rel="noopener" className="px-3 py-2 rounded-full bg-[var(--green)] text-white text-[12px] font-extrabold flex items-center gap-1"><MessageCircle size={13} /> واتساب لولي الأمر</a> : <span className="text-[11px] text-[var(--muted)] font-bold py-2">لا يوجد رقم مسجّل.</span>}</div></div>}</div>}</div>; })}</div><button onClick={onSave} disabled={busy} className="w-full mt-4 bg-[var(--green)] text-white py-3.5 rounded-xl font-extrabold flex items-center justify-center gap-2 disabled:opacity-60"><Save size={17} /> {busy ? "جارٍ الحفظ…" : "حفظ حضور اليوم"}</button>{saveInfo && <p className="text-center text-[12.5px] font-bold text-emerald-700 mt-2 flex items-center justify-center gap-1"><Check size={14} /> {saveInfo}</p>}</div></div>;
}
function FollowupPanel({ students, grades, setGrades, editing, setEditing, draft, setDraft, onSave, busy }: any) {
  return <div className="card overflow-hidden"><div className="p-4 flex flex-wrap justify-between gap-3"><p className="font-bold text-[13px] text-[var(--muted)]">اضغط على أي درجة واكتب رقماً من 0 إلى 10 ثم اضغط ✓</p><button onClick={onSave} disabled={busy} className="px-4 py-2.5 rounded-full bg-[var(--primary)] text-white font-extrabold text-[13px] disabled:opacity-60">حفظ الدرجات</button></div><div className="overflow-x-auto"><table className="w-full text-[13.5px] min-w-[620px]"><thead className="bg-[var(--bg)]"><tr><th className="p-3.5 text-start">الابن</th><th className="p-3.5">الواجب / 10</th><th className="p-3.5">المشاركة / 10</th><th className="p-3.5">السلوك / 10</th><th className="p-3.5">المجموع / 30</th></tr></thead><tbody>{students.map((s: any) => { const g = grades[s.id]; return <tr key={s.id} className="border-t border-[var(--line)]"><td className="p-3.5 font-bold">{s.name}</td>{(["h", "p", "b"] as const).map((k) => { const key = `${s.id}-${k}`; return <td key={k} className="p-3.5 text-center">{editing === key ? <span className="inline-flex items-center gap-1"><input value={draft} onChange={(e) => setDraft(e.target.value.replace(/[^0-9]/g, ""))} className="w-14 border border-[var(--primary)] rounded-lg px-2 py-1.5 text-center font-black" autoFocus /><button onClick={() => { const n = Math.max(0, Math.min(10, Number(draft || 0))); setGrades({ ...grades, [s.id]: { ...g, [k]: n } }); setEditing(null); }} className="w-7 h-7 grid place-items-center rounded-full bg-emerald-500 text-white"><Check size={14} /></button></span> : <button onClick={() => { setEditing(key); setDraft(String(g[k])); }} className="min-w-[42px] px-3 py-1.5 rounded-full bg-[var(--bg)] font-black num hover:bg-[var(--primary-soft)]">{g[k]}</button>}</td>; })}<td className="p-3.5 text-center"><span className={`chip ${g.h + g.p + g.b >= 25 ? "bg-emerald-50 text-emerald-700" : g.h + g.p + g.b >= 18 ? "bg-amber-50 text-amber-700" : "bg-rose-50 text-rose-600"}`}>{g.h + g.p + g.b}</span></td></tr>; })}</tbody></table></div></div>;
}
function Modal({ children, onClose, title }: any) {
  return <div className="fixed inset-0 z-50 grid place-items-center p-4"><div className="absolute inset-0 bg-black/45" onClick={onClose} /><div className="relative card w-full max-w-[620px] max-h-[90vh] overflow-y-auto p-5 sm:p-6 pop"><div className="flex justify-between items-center mb-4"><h3 className="text-[19px] font-black">{title}</h3><button onClick={onClose} className="w-9 h-9 grid place-items-center rounded-full bg-[var(--bg)]"><X size={18} /></button></div>{children}<button onClick={onClose} className="w-full mt-5 py-3 rounded-xl border border-[var(--line)] font-extrabold">إغلاق المعاينة</button></div></div>;
}
